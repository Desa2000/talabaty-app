import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/providers/auth_provider.dart';
import '../../../core/providers/data_provider.dart';
import '../../../core/providers/notification_provider.dart';
import '../../../core/constants/enums.dart';

class RegisterScreen extends StatefulWidget {
  final String phone;
  final String email;
  const RegisterScreen({super.key, required this.phone, required this.email});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  // Common Fields
  final _nameController = TextEditingController();
  UserRole _selectedRole = UserRole.customer;

  // Courier Fields
  VehicleType _selectedVehicle = VehicleType.motorcycle;
  final _licensePlateController = TextEditingController();
  final _idNumberController = TextEditingController();

  // Merchant Fields
  final _businessNameController = TextEditingController();
  final _businessDescController = TextEditingController();
  StoreType _selectedStoreType = StoreType.restaurant;
  final _businessAreaController = TextEditingController();
  XFile? _storeLogo;

  bool _isLoading = false;

  Future<void> _register() async {
    if (_nameController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('الرجاء كتابة الاسم')));
      return;
    }

    setState(() => _isLoading = true);
    final authProvider = context.read<AuthProvider>();
    final dataProvider = context.read<DataProvider>();

    Map<String, dynamic> extraData = {};
    if (_selectedRole == UserRole.courier) {
      extraData = {
        'vehicleType': _selectedVehicle,
        'licensePlate': _licensePlateController.text,
        'idNumber': _idNumberController.text,
      };
    } else if (_selectedRole == UserRole.merchant) {
      extraData = {
        'businessName': _businessNameController.text.isEmpty ? 'متجر جديد' : _businessNameController.text,
        'businessDescription': _businessDescController.text,
        'storeType': _selectedStoreType,
        'businessArea': _businessAreaController.text.isEmpty ? 'الخرطوم' : _businessAreaController.text,
        'logoPath': _storeLogo?.path,
      };
    }

    try {
      await authProvider.register(
        name: _nameController.text.trim(),
        phone: widget.phone,
        email: widget.email,
        role: _selectedRole,
      );
      
      if (mounted) {
        context.read<NotificationProvider>().initFCM();
      }

      setState(() => _isLoading = false);

      if (mounted) {
        if (_selectedRole == UserRole.customer) context.go('/customer');
        else if (_selectedRole == UserRole.courier) context.go('/courier');
        else if (_selectedRole == UserRole.merchant) context.go('/merchant');
        else if (_selectedRole == UserRole.admin) context.go('/admin');
      }
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('إكمال التسجيل'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 1,
      ),
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Directionality(
          textDirection: TextDirection.rtl,
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Center(
                  child: Column(
                    children: [
                      const Icon(Icons.verified_user, size: 64, color: AppColors.primaryColor),
                      const SizedBox(height: 16),
                      Text('تم توثيق الرقم: ${widget.phone}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.green)),
                      const SizedBox(height: 8),
                      const Text('أهلاً بك! لنكمل إنشاء حسابك', style: TextStyle(color: AppColors.textSecondary)),
                    ],
                  ),
                ),
                const SizedBox(height: 32),
                
                const Text('اختر نوع الحساب', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                SegmentedButton<UserRole>(
                  segments: const [
                    ButtonSegment(value: UserRole.customer, label: Text('عميل'), icon: Icon(Icons.person)),
                    ButtonSegment(value: UserRole.courier, label: Text('مندوب'), icon: Icon(Icons.motorcycle)),
                    ButtonSegment(value: UserRole.merchant, label: Text('تاجر'), icon: Icon(Icons.store)),
                  ],
                  selected: {_selectedRole},
                  onSelectionChanged: (Set<UserRole> newSelection) {
                    setState(() {
                      _selectedRole = newSelection.first;
                    });
                  },
                ),
                const SizedBox(height: 32),
                
                const Text('الاسم الكامل', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                TextField(
                  controller: _nameController,
                  decoration: InputDecoration(
                    hintText: _selectedRole == UserRole.merchant ? 'اسم مالك المتجر' : 'اسمك الثلاثي',
                    prefixIcon: const Icon(Icons.person_outline),
                    filled: true,
                    fillColor: Colors.grey.withValues(alpha: 0.1),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                  ),
                ),
                
                if (_selectedRole == UserRole.courier) ...[
                  const SizedBox(height: 32),
                  const Text('معلومات المركبة (اختياري)', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 16),
                  DropdownButtonFormField<VehicleType>(
                    value: _selectedVehicle,
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.grey.withValues(alpha: 0.1),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                      prefixIcon: const Icon(Icons.directions_car_outlined),
                    ),
                    items: const [
                      DropdownMenuItem(value: VehicleType.motorcycle, child: Text('دراجة نارية (مواتر)')),
                      DropdownMenuItem(value: VehicleType.car, child: Text('سيارة')),
                      DropdownMenuItem(value: VehicleType.bicycle, child: Text('دراجة هوائية')),
                    ],
                    onChanged: (val) => setState(() => _selectedVehicle = val!),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _licensePlateController,
                    decoration: InputDecoration(
                      hintText: 'رقم اللوحة',
                      prefixIcon: const Icon(Icons.pin_outlined),
                      filled: true,
                      fillColor: Colors.grey.withValues(alpha: 0.1),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                    ),
                  ),
                ],

                if (_selectedRole == UserRole.merchant) ...[
                  const SizedBox(height: 32),
                  const Text('معلومات المتجر (اختياري الآن)', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 16),
                  Center(
                    child: GestureDetector(
                      onTap: () async {
                        final picker = ImagePicker();
                        final pickedImage = await picker.pickImage(source: ImageSource.gallery);
                        if (pickedImage != null) {
                          setState(() {
                            _storeLogo = pickedImage;
                          });
                        }
                      },
                      child: CircleAvatar(
                        radius: 40,
                        backgroundColor: Colors.grey.withValues(alpha: 0.2),
                        backgroundImage: _storeLogo != null ? FileImage(File(_storeLogo!.path)) : null,
                        child: _storeLogo == null ? const Icon(Icons.add_a_photo, size: 30, color: Colors.grey) : null,
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _businessNameController,
                    decoration: InputDecoration(
                      hintText: 'اسم النشاط التجاري (المطعم/المتجر)',
                      prefixIcon: const Icon(Icons.storefront_outlined),
                      filled: true,
                      fillColor: Colors.grey.withValues(alpha: 0.1),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                    ),
                  ),
                  const SizedBox(height: 16),
                  DropdownButtonFormField<StoreType>(
                    value: _selectedStoreType,
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.grey.withValues(alpha: 0.1),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                      prefixIcon: const Icon(Icons.category_outlined),
                    ),
                    items: const [
                      DropdownMenuItem(value: StoreType.restaurant, child: Text('مطعم')),
                      DropdownMenuItem(value: StoreType.supermarket, child: Text('سوبرماركت')),
                      DropdownMenuItem(value: StoreType.pharmacy, child: Text('صيدلية')),
                    ],
                    onChanged: (val) => setState(() => _selectedStoreType = val!),
                  ),
                ],

                const SizedBox(height: 40),
                SizedBox(
                  height: 56,
                  child: ElevatedButton(
                    onPressed: _isLoading ? null : _register,
                    style: ElevatedButton.styleFrom(
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      backgroundColor: AppColors.primaryColor,
                      foregroundColor: Colors.white,
                      elevation: 0,
                    ),
                    child: _isLoading
                      ? const SizedBox(height: 24, width: 24, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                      : const Text('دخول', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
