import 'package:talabaty_app/core/widgets/custom_image.dart';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/providers/product_provider.dart';
import '../../../data/models/product_model.dart';
import 'package:uuid/uuid.dart';

class EditProductScreen extends StatefulWidget {
  final ProductModel product;
  const EditProductScreen({super.key, required this.product});

  @override
  State<EditProductScreen> createState() => _EditProductScreenState();
}

class _EditProductScreenState extends State<EditProductScreen> {
  final _formKey = GlobalKey<FormState>();

  late String _name;
  late String _description;
  late String _category;
  late double _price;
  double? _discountPrice;
  late int _stockQuantity;
  late int _lowStockThreshold;
  late int _prepTime;
  late bool _isAvailable;
  late bool _isFeatured;
  late bool _allowCustomerNotes;
  
  File? _imageFile;
  final ImagePicker _picker = ImagePicker();
  
  late List<ProductOptionGroup> _optionGroups;
  late List<ProductAddOn> _addOns;

  final List<String> _categories = ['ÙˆØ¬Ø¨Ø§Øª Ø±Ø¦ÙŠØ³ÙŠØ©', 'Ù…Ø´ÙˆÙŠØ§Øª', 'Ø³Ù†Ø¯ÙˆØªØ´Ø§Øª', 'Ø¨ÙŠØªØ²Ø§', 'Ø¥Ø¶Ø§ÙØ§Øª', 'Ø§Ù„Ù…Ø´Ø±ÙˆØ¨Ø§Øª'];

  @override
  void initState() {
    super.initState();
    _name = widget.product.name;
    _description = widget.product.description;
    _category = _categories.contains(widget.product.category) ? widget.product.category : _categories.first;
    _price = widget.product.price;
    _discountPrice = widget.product.discountPrice;
    _stockQuantity = widget.product.stockQuantity;
    _lowStockThreshold = widget.product.lowStockThreshold;
    _prepTime = widget.product.preparationTimeMinutes;
    _isAvailable = widget.product.isAvailable;
    _isFeatured = widget.product.isFeatured;
    _allowCustomerNotes = widget.product.allowCustomerNotes;
    _optionGroups = List.from(widget.product.optionGroups);
    _addOns = List.from(widget.product.addOns);
  }

  Future<void> _pickImage() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _imageFile = File(pickedFile.path);
      });
    }
  }

  void _showAddOptionGroupDialog() {
    String groupName = '';
    bool isRequired = true;
    List<ProductOption> tempOptions = [];
    final uuid = const Uuid();

    showDialog(
      context: context,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: const Text('Ø¥Ø¶Ø§ÙØ© Ù…Ø¬Ù…ÙˆØ¹Ø© Ø®ÙŠØ§Ø±Ø§Øª (Ù…Ø«Ø§Ù„: Ø§Ù„Ø­Ø¬Ù…)'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      decoration: const InputDecoration(labelText: 'Ø§Ø³Ù… Ø§Ù„Ù…Ø¬Ù…ÙˆØ¹Ø© (Ù…Ø«Ø§Ù„: Ø§Ø®ØªØ± Ø§Ù„Ø­Ø¬Ù…)'),
                      onChanged: (v) => groupName = v,
                    ),
                    SwitchListTile(
                      title: const Text('Ø¥Ø¬Ø¨Ø§Ø±ÙŠØŸ (ÙŠØ¬Ø¨ Ø£Ù† ÙŠØ®ØªØ§Ø± Ø§Ù„Ø¹Ù…ÙŠÙ„)'),
                      value: isRequired,
                      onChanged: (v) => setDialogState(() => isRequired = v),
                    ),
                    const Divider(),
                    const Text('Ø§Ù„Ø®ÙŠØ§Ø±Ø§Øª:', style: TextStyle(fontWeight: FontWeight.bold)),
                    ...tempOptions.map((opt) => ListTile(
                      title: Text(opt.name),
                      subtitle: Text('+ ${opt.extraPrice} Ø¬.Ø³'),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () => setDialogState(() => tempOptions.remove(opt)),
                      ),
                    )),
                    ElevatedButton.icon(
                      onPressed: () {
                        String optName = '';
                        double optPrice = 0.0;
                        showDialog(
                          context: context,
                          builder: (_) => AlertDialog(
                            title: const Text('Ø®ÙŠØ§Ø± Ø¬Ø¯ÙŠØ¯'),
                            content: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                TextField(decoration: const InputDecoration(labelText: 'Ø§Ø³Ù… Ø§Ù„Ø®ÙŠØ§Ø± (Ù…Ø«Ø§Ù„: ÙƒØ¨ÙŠØ±)'), onChanged: (v) => optName = v),
                                TextField(decoration: const InputDecoration(labelText: 'Ø§Ù„Ø³Ø¹Ø± Ø§Ù„Ø¥Ø¶Ø§ÙÙŠ'), keyboardType: TextInputType.number, onChanged: (v) => optPrice = double.tryParse(v) ?? 0.0),
                              ],
                            ),
                            actions: [
                              TextButton(onPressed: () => Navigator.pop(context), child: const Text('Ø¥Ù„ØºØ§Ø¡')),
                              ElevatedButton(
                                onPressed: () {
                                  if (optName.isNotEmpty) {
                                    setDialogState(() {
                                      tempOptions.add(ProductOption(id: uuid.v4(), name: optName, extraPrice: optPrice));
                                    });
                                    Navigator.pop(context);
                                  }
                                },
                                child: const Text('Ø¥Ø¶Ø§ÙØ©'),
                              )
                            ],
                          )
                        );
                      },
                      icon: const Icon(Icons.add),
                      label: const Text('Ø¥Ø¶Ø§ÙØ© Ø®ÙŠØ§Ø±'),
                    )
                  ],
                ),
              ),
              actions: [
                TextButton(onPressed: () => Navigator.pop(context), child: const Text('Ø¥Ù„ØºØ§Ø¡')),
                ElevatedButton(
                  onPressed: () {
                    if (groupName.isNotEmpty && tempOptions.isNotEmpty) {
                      setState(() {
                        _optionGroups.add(ProductOptionGroup(
                          id: uuid.v4(),
                          name: groupName,
                          isRequired: isRequired,
                          options: tempOptions,
                        ));
                      });
                      Navigator.pop(context);
                    }
                  },
                  child: const Text('Ø­ÙØ¸ Ø§Ù„Ù…Ø¬Ù…ÙˆØ¹Ø©'),
                )
              ],
            );
          }
        );
      }
    );
  }

  void _showAddAddOnDialog() {
    String addOnName = '';
    double addOnPrice = 0.0;
    final uuid = const Uuid();

    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: const Text('Ø¥Ø¶Ø§ÙØ© Ù…Ù„Ø­Ù‚ (Ù…Ø«Ø§Ù„: ÙƒØ§ØªØ´Ø¨)'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(decoration: const InputDecoration(labelText: 'Ø§Ø³Ù… Ø§Ù„Ù…Ù„Ø­Ù‚'), onChanged: (v) => addOnName = v),
              TextField(decoration: const InputDecoration(labelText: 'Ø§Ù„Ø³Ø¹Ø± Ø§Ù„Ø¥Ø¶Ø§ÙÙŠ'), keyboardType: TextInputType.number, onChanged: (v) => addOnPrice = double.tryParse(v) ?? 0.0),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Ø¥Ù„ØºØ§Ø¡')),
            ElevatedButton(
              onPressed: () {
                if (addOnName.isNotEmpty) {
                  setState(() {
                    _addOns.add(ProductAddOn(id: uuid.v4(), name: addOnName, price: addOnPrice));
                  });
                  Navigator.pop(context);
                }
              },
              child: const Text('Ø¥Ø¶Ø§ÙØ©'),
            )
          ],
        );
      }
    );
  }

  void _saveProduct() {
    if (_formKey.currentState?.validate() != true) return;
    _formKey.currentState?.save();

    final updatedProduct = widget.product.copyWith(
      name: _name,
      description: _description,
      category: _category,
      price: _price,
      discountPrice: _discountPrice,
      stockQuantity: _stockQuantity,
      lowStockThreshold: _lowStockThreshold,
      preparationTimeMinutes: _prepTime,
      isAvailable: _isAvailable,
      isFeatured: _isFeatured,
      allowCustomerNotes: _allowCustomerNotes,
      optionGroups: _optionGroups,
      addOns: _addOns,
      updatedAt: DateTime.now(),
      image: _imageFile != null ? _imageFile!.path : widget.product.image,
    );

    context.read<ProductProvider>().updateProduct(updatedProduct).then((_) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('ØªÙ… ØªØ¹Ø¯ÙŠÙ„ Ø§Ù„Ù…Ù†ØªØ¬ Ø¨Ù†Ø¬Ø§Ø­')));
      context.pop();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(title: const Text('ØªØ¹Ø¯ÙŠÙ„ Ø§Ù„Ù…Ù†ØªØ¬')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildSectionHeader('Ù…Ø¹Ù„ÙˆÙ…Ø§Øª Ø§Ù„Ù…Ù†ØªØ¬ Ø§Ù„Ø£Ø³Ø§Ø³ÙŠØ©'),
              _buildCard(
                child: Column(
                  children: [
                    TextFormField(
                      initialValue: _name,
                      decoration: const InputDecoration(labelText: 'Ø§Ø³Ù… Ø§Ù„Ù…Ù†ØªØ¬ *', border: OutlineInputBorder()),
                      validator: (v) => v == null || v.isEmpty ? 'Ø§Ù„Ø±Ø¬Ø§Ø¡ Ø¥Ø¯Ø®Ø§Ù„ Ø§Ø³Ù… Ø§Ù„Ù…Ù†ØªØ¬' : null,
                      onSaved: (v) => _name = v!,
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      initialValue: _description,
                      decoration: const InputDecoration(labelText: 'ÙˆØµÙ Ø§Ù„Ù…Ù†ØªØ¬ *', border: OutlineInputBorder()),
                      maxLines: 3,
                      validator: (v) => v == null || v.isEmpty ? 'Ø§Ù„Ø±Ø¬Ø§Ø¡ Ø¥Ø¯Ø®Ø§Ù„ ÙˆØµÙ Ø§Ù„Ù…Ù†ØªØ¬' : null,
                      onSaved: (v) => _description = v!,
                    ),
                  ],
                ),
              ),

              _buildSectionHeader('Ø§Ù„Ø³Ø¹Ø± ÙˆØ§Ù„Ù…Ø®Ø²ÙˆÙ†'),
              _buildCard(
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: TextFormField(
                            initialValue: _price.toString(),
                            decoration: const InputDecoration(labelText: 'Ø§Ù„Ø³Ø¹Ø± Ø§Ù„Ø£Ø³Ø§Ø³ÙŠ *', border: OutlineInputBorder()),
                            keyboardType: TextInputType.number,
                            validator: (v) {
                              if (v == null || v.isEmpty) return 'Ø§Ù„Ø±Ø¬Ø§Ø¡ Ø¥Ø¯Ø®Ø§Ù„ Ø§Ù„Ø³Ø¹Ø±';
                              if (double.tryParse(v) == null || double.parse(v) <= 0) return 'Ø§Ù„Ø³Ø¹Ø± ÙŠØ¬Ø¨ Ø£Ù† ÙŠÙƒÙˆÙ† Ø£ÙƒØ¨Ø± Ù…Ù† ØµÙØ±';
                              return null;
                            },
                            onSaved: (v) => _price = double.parse(v!),
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: TextFormField(
                            initialValue: _discountPrice?.toString(),
                            decoration: const InputDecoration(labelText: 'Ø³Ø¹Ø± Ø¨Ø¹Ø¯ Ø§Ù„Ø®ØµÙ… (Ø§Ø®ØªÙŠØ§Ø±ÙŠ)', border: OutlineInputBorder()),
                            keyboardType: TextInputType.number,
                            onSaved: (v) {
                              if (v != null && v.isNotEmpty) {
                                _discountPrice = double.tryParse(v);
                              } else {
                                _discountPrice = null;
                              }
                            },
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: TextFormField(
                            initialValue: _stockQuantity.toString(),
                            decoration: const InputDecoration(labelText: 'Ø§Ù„ÙƒÙ…ÙŠØ© ÙÙŠ Ø§Ù„Ù…Ø®Ø²ÙˆÙ† *', border: OutlineInputBorder()),
                            keyboardType: TextInputType.number,
                            validator: (v) => v == null || v.isEmpty ? 'Ø§Ù„Ø±Ø¬Ø§Ø¡ Ø¥Ø¯Ø®Ø§Ù„ Ø§Ù„ÙƒÙ…ÙŠØ©' : null,
                            onSaved: (v) => _stockQuantity = int.parse(v!),
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: TextFormField(
                            initialValue: _lowStockThreshold.toString(),
                            decoration: const InputDecoration(labelText: 'ØªÙ†Ø¨ÙŠÙ‡ Ø§Ù†Ø®ÙØ§Ø¶ Ø§Ù„Ù…Ø®Ø²ÙˆÙ†', border: OutlineInputBorder()),
                            keyboardType: TextInputType.number,
                            onSaved: (v) => _lowStockThreshold = int.parse(v!),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              _buildSectionHeader('Ø§Ù„ØµÙˆØ±Ø© ÙˆØ§Ù„ØªØµÙ†ÙŠÙ'),
              _buildCard(
                child: Column(
                  children: [
                    DropdownButtonFormField<String>(
                      value: _category,
                      decoration: const InputDecoration(labelText: 'ØªØµÙ†ÙŠÙ Ø§Ù„Ù…Ù†ØªØ¬ *', border: OutlineInputBorder()),
                      items: _categories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                      onChanged: (v) => setState(() => _category = v!),
                      onSaved: (v) => _category = v!,
                    ),
                    const SizedBox(height: 16),
                    InkWell(
                      onTap: _pickImage,
                      child: Container(
                        height: 150,
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: Colors.grey[200],
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.grey),
                        ),
                        child: _imageFile != null
                            ? ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.file(_imageFile!, fit: BoxFit.cover))
                            : ClipRRect(borderRadius: BorderRadius.circular(12), child: CustomImage(imagePath: widget.product.image, fit: BoxFit.cover)),
                      ),
                    ),
                  ],
                ),
              ),

              _buildSectionHeader('Ø§Ù„Ø®ÙŠØ§Ø±Ø§Øª ÙˆØ§Ù„Ø¥Ø¶Ø§ÙØ§Øª'),
              _buildCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Ù…Ø¬Ù…ÙˆØ¹Ø§Øª Ø§Ù„Ø®ÙŠØ§Ø±Ø§Øª Ø§Ù„Ø­Ø§Ù„ÙŠØ©: ${_optionGroups.length}', style: const TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    ..._optionGroups.map((group) => Card(
                      color: AppColors.backgroundLight,
                      child: ListTile(
                        title: Text('${group.name} (${group.isRequired ? 'Ø¥Ø¬Ø¨Ø§Ø±ÙŠ' : 'Ø§Ø®ØªÙŠØ§Ø±ÙŠ'})'),
                        subtitle: Text('${group.options.length} Ø®ÙŠØ§Ø±Ø§Øª'),
                        trailing: IconButton(
                          icon: const Icon(Icons.delete, color: Colors.red),
                          onPressed: () => setState(() => _optionGroups.remove(group)),
                        ),
                      ),
                    )),
                    const SizedBox(height: 8),
                    ElevatedButton.icon(
                      onPressed: _showAddOptionGroupDialog,
                      icon: const Icon(Icons.add),
                      label: const Text('Ø¥Ø¶Ø§ÙØ© Ù…Ø¬Ù…ÙˆØ¹Ø© Ø®ÙŠØ§Ø±Ø§Øª (Ù…Ø«Ø§Ù„: Ø§Ù„Ø­Ø¬Ù…)'),
                    ),
                    const Padding(padding: EdgeInsets.symmetric(vertical: 16), child: Divider()),
                    Text('Ø§Ù„Ø¥Ø¶Ø§ÙØ§Øª Ø§Ù„Ø­Ø§Ù„ÙŠØ©: ${_addOns.length}', style: const TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      children: _addOns.map((addon) => Chip(
                        label: Text('${addon.name} (+${addon.price} Ø¬.Ø³)'),
                        deleteIcon: const Icon(Icons.close, size: 18),
                        onDeleted: () => setState(() => _addOns.remove(addon)),
                      )).toList(),
                    ),
                    const SizedBox(height: 8),
                    ElevatedButton.icon(
                      onPressed: _showAddAddOnDialog,
                      icon: const Icon(Icons.add),
                      label: const Text('Ø¥Ø¶Ø§ÙØ© Ù…Ù„Ø­Ù‚ (Ù…Ø«Ø§Ù„: Ø¬Ø¨Ù†Ø©)'),
                    ),
                  ],
                ),
              ),

              _buildSectionHeader('Ø§Ù„Ø¥Ø¹Ø¯Ø§Ø¯Ø§Øª'),
              _buildCard(
                child: Column(
                  children: [
                    SwitchListTile(
                      title: const Text('Ø§Ù„Ù…Ù†ØªØ¬ Ù…ØªØ§Ø­'),
                      value: _isAvailable,
                      onChanged: (v) => setState(() => _isAvailable = v),
                      activeColor: AppColors.primaryColor,
                    ),
                    SwitchListTile(
                      title: const Text('Ù…Ù†ØªØ¬ Ù…Ù…ÙŠØ²'),
                      value: _isFeatured,
                      onChanged: (v) => setState(() => _isFeatured = v),
                      activeColor: AppColors.primaryColor,
                    ),
                    SwitchListTile(
                      title: const Text('Ø§Ù„Ø³Ù…Ø§Ø­ Ø¨Ù…Ù„Ø§Ø­Ø¸Ø§Øª Ø§Ù„Ø¹Ù…ÙŠÙ„'),
                      value: _allowCustomerNotes,
                      onChanged: (v) => setState(() => _allowCustomerNotes = v),
                      activeColor: AppColors.primaryColor,
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      onPressed: _saveProduct,
                      style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryColor, padding: const EdgeInsets.symmetric(vertical: 16)),
                      child: const Text('Ø­ÙØ¸ Ø§Ù„ØªØ¹Ø¯ÙŠÙ„Ø§Øª', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => context.pop(),
                      style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)),
                      child: const Text('Ø¥Ù„ØºØ§Ø¡', style: TextStyle(fontSize: 18)),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: TextButton.icon(
                  onPressed: () {
                    context.read<ProductProvider>().deleteProduct(widget.product.id);
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('ØªÙ… Ø­Ø°Ù Ø§Ù„Ù…Ù†ØªØ¬ Ø¨Ù†Ø¬Ø§Ø­')));
                    context.pop();
                  },
                  icon: const Icon(Icons.delete, color: Colors.red),
                  label: const Text('Ø­Ø°Ù Ø§Ù„Ù…Ù†ØªØ¬', style: TextStyle(color: Colors.red, fontSize: 18)),
                ),
              ),
              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.only(top: 24, bottom: 12),
      child: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
    );
  }

  Widget _buildCard({required Widget child}) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: child,
      ),
    );
  }
}

