import 'package:flutter/material.dart';
import 'package:talabaty_app/core/utils/directional_extensions.dart';
import 'package:provider/provider.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/providers/auth_provider.dart';
import '../../../../core/providers/data_provider.dart';
import '../../../../core/services/firestore_service.dart';
import '../../../../data/models/store_model.dart';


class MerchantSettingsTab extends StatefulWidget {
  const MerchantSettingsTab({super.key});

  @override
  State<MerchantSettingsTab> createState() => _MerchantSettingsTabState();
}

class _MerchantSettingsTabState extends State<MerchantSettingsTab> {
  bool _isOpen = true;
  bool _isUpdating = false;

  Future<void> _toggleStoreStatus(String storeId, bool newValue) async {
    setState(() => _isUpdating = true);
    try {
      final firestoreService = FirestoreService();
      await firestoreService.updateStoreStatus(storeId, newValue ? 'active' : 'closed');
      setState(() => _isOpen = newValue);
      if (mounted) {
        ScaffoldMessenger.of(context).hideCurrentSnackBar();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              newValue ? 'تم فتح المتجر بنجاح' : 'تم إغلاق المتجر وإيقاف استقبال الطلبات',
              style: const TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.bold),
            ),
            backgroundColor: newValue ? Colors.green.shade700 : Colors.red.shade700,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('حدث خطأ، يرجى المحاولة مرة أخرى', style: TextStyle(fontFamily: 'Cairo')),
            backgroundColor: Colors.red.shade700,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isUpdating = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final dataProvider = context.watch<DataProvider>();
    if (!auth.isAuthenticated) return const SizedBox();

    // Get the merchant's real store
    final merchantId = auth.currentUser?.id ?? '';
    if (dataProvider.stores.isEmpty) {
      return const Center(
        child: Text(
          'لا يوجد متجر مرتبط',
          style: TextStyle(fontSize: 16, fontFamily: 'Cairo', color: AppColors.textSecondary),
        ),
      );
    }

    final store = dataProvider.stores.firstWhere(
      (s) => s.ownerId == merchantId,
      orElse: () => dataProvider.stores.first,
    );

    // Sync with real status on first build
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (store.status == 'active' && !_isOpen) {
        setState(() => _isOpen = true);
      } else if (store.status != 'active' && _isOpen) {
        setState(() => _isOpen = false);
      }
    });

    final statusColor = _isOpen ? const Color(0xFF2E7D32) : const Color(0xFFC62828);

    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        title: const Text(
          'إعدادات المتجر',
          style: TextStyle(fontWeight: FontWeight.bold, fontFamily: 'Cairo'),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        foregroundColor: AppColors.textPrimary,
        elevation: 0,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.borderGray, height: 1),
        ),
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Store Status Toggle Card
            Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: statusColor.withValues(alpha: 0.15), width: 1.5),
                boxShadow: [
                  BoxShadow(
                    color: statusColor.withValues(alpha: 0.05),
                    blurRadius: 16,
                    offset: const Offset(0, 8),
                  )
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 10,
                              height: 10,
                              decoration: BoxDecoration(
                                color: statusColor,
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: 8),
                            Text(
                              _isOpen ? 'المتجر مفتوح' : 'المتجر مغلق',
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: statusColor,
                                fontFamily: 'Cairo',
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Text(
                          _isOpen ? 'يستقبل الطلبات حالياً' : 'مغلق ولا يستقبل أي طلبات',
                          style: const TextStyle(
                            color: AppColors.textSecondary,
                            fontSize: 14,
                            fontFamily: 'Cairo',
                          ),
                        ),
                      ],
                    ),
                  ),
                  _isUpdating
                      ? const CircularProgressIndicator()
                      : Switch(
                          value: _isOpen,
                          activeColor: statusColor,
                          activeTrackColor: statusColor.withValues(alpha: 0.2),
                          inactiveThumbColor: Colors.grey.shade400,
                          inactiveTrackColor: Colors.grey.shade200,
                          onChanged: (val) => _toggleStoreStatus(store.id, val),
                        ),
                ],
              ),
            ),
            const SizedBox(height: 32),

            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 4),
              child: Text(
                'المعلومات الأساسية',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textPrimary,
                  fontFamily: 'Cairo',
                ),
              ),
            ),
            const SizedBox(height: 16),

            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: AppColors.borderGray.withValues(alpha: 0.6), width: 1.5),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.02),
                    blurRadius: 14,
                    offset: const Offset(0, 6),
                  )
                ],
              ),
              child: Column(
                children: [
                  _buildSettingsItem(
                    icon: Icons.store_rounded, 
                    title: 'اسم المطعم', 
                    subtitle: store.name,
                    onTap: () => _editStoreField(store, 'name', store.name, 'اسم المطعم'),
                  ),
                  const Divider(height: 1, indent: 64, color: AppColors.borderGray),
                  _buildSettingsItem(
                    icon: Icons.phone_rounded, 
                    title: 'رقم الهاتف', 
                    subtitle: store.phone,
                    onTap: () => _editStoreField(store, 'phone', store.phone, 'رقم الهاتف'),
                  ),
                  const Divider(height: 1, indent: 64, color: AppColors.borderGray),
                  _buildSettingsItem(
                    icon: Icons.access_time_rounded, 
                    title: 'أوقات العمل', 
                    subtitle: '${store.openingTime} - ${store.closingTime}',
                    onTap: () => _editStoreField(store, 'hours', '${store.openingTime} - ${store.closingTime}', 'أوقات العمل (صيغة: 09:00 - 22:00)'),
                  ),
                  const Divider(height: 1, indent: 64, color: AppColors.borderGray),
                  _buildSettingsItem(
                    icon: Icons.map_rounded, 
                    title: 'المنطقة', 
                    subtitle: '${store.area} - ${store.street}',
                    onTap: () => _editStoreField(store, 'area', store.area, 'المنطقة'),
                  ),
                  const Divider(height: 1, indent: 64, color: AppColors.borderGray),
                  _buildSettingsItem(
                    icon: Icons.delivery_dining_rounded, 
                    title: 'رسوم التوصيل', 
                    subtitle: '${store.deliveryFee.toInt()} ج.س',
                    onTap: () => _editStoreField(store, 'deliveryFee', store.deliveryFee.toInt().toString(), 'رسوم التوصيل'),
                  ),
                ],
              ),
            ),
            
            const SizedBox(height: 40),
            SizedBox(
              width: double.infinity,
              height: 54,
              child: OutlinedButton(
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.red.shade700,
                  side: BorderSide(color: Colors.red.shade200, width: 1.5),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  backgroundColor: Colors.red.shade50.withValues(alpha: 0.5),
                ),
                onPressed: () => auth.logout(),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.logout_rounded, size: 20),
                    SizedBox(width: 8),
                    Text(
                      'تسجيل الخروج',
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, fontFamily: 'Cairo'),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  void _editStoreField(StoreModel store, String fieldName, String currentValue, String label) {
    final controller = TextEditingController(text: currentValue);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        backgroundColor: Colors.white,
        title: Text(
          'تعديل $label',
          style: const TextStyle(fontWeight: FontWeight.bold, fontFamily: 'Cairo', fontSize: 18),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: controller,
              decoration: InputDecoration(
                labelText: label,
                labelStyle: const TextStyle(fontFamily: 'Cairo', color: AppColors.textSecondary),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: const BorderSide(color: AppColors.borderGray, width: 1.5),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: const BorderSide(color: AppColors.primaryColor, width: 1.5),
                ),
                filled: true,
                fillColor: AppColors.backgroundLight.withValues(alpha: 0.5),
              ),
              style: const TextStyle(fontFamily: 'Cairo'),
              keyboardType: fieldName == 'deliveryFee' ? TextInputType.number : TextInputType.text,
            ),
          ],
        ),
        actionsPadding: const EdgeInsets.only(left: 16, right: 16, bottom: 16),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('إلغاء', style: TextStyle(color: Colors.grey, fontFamily: 'Cairo', fontWeight: FontWeight.bold)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primaryColor,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              elevation: 0,
            ),
            onPressed: () async {
              final newValue = controller.text.trim();
              if (newValue.isEmpty) return;
              
              StoreModel updatedStore;
              if (fieldName == 'name') {
                updatedStore = store.copyWith(name: newValue);
              } else if (fieldName == 'phone') {
                updatedStore = store.copyWith(phone: newValue);
              } else if (fieldName == 'deliveryFee') {
                final fee = double.tryParse(newValue) ?? store.deliveryFee;
                updatedStore = store.copyWith(deliveryFee: fee);
              } else if (fieldName == 'hours') {
                final parts = newValue.split('-');
                final open = parts[0].trim();
                final close = parts.length > 1 ? parts[1].trim() : store.closingTime;
                updatedStore = store.copyWith(openingTime: open, closingTime: close);
              } else if (fieldName == 'area') {
                updatedStore = store.copyWith(area: newValue);
              } else {
                return;
              }
              
              Navigator.pop(ctx);
              setState(() => _isUpdating = true);
              try {
                await FirestoreService().saveStore(updatedStore);
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: const Text('تم تحديث البيانات بنجاح', style: TextStyle(fontFamily: 'Cairo')),
                      backgroundColor: Colors.green.shade700,
                      behavior: SnackBarBehavior.floating,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  );
                }
              } catch (e) {
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: const Text('فشل التحديث، يرجى المحاولة لاحقاً', style: TextStyle(fontFamily: 'Cairo')),
                      backgroundColor: Colors.red.shade700,
                      behavior: SnackBarBehavior.floating,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  );
                }
              } finally {
                if (mounted) setState(() => _isUpdating = false);
              }
            },
            child: const Text('حفظ', style: TextStyle(color: Colors.white, fontFamily: 'Cairo', fontWeight: FontWeight.bold)),
          )
        ],
      ),
    );
  }

  Widget _buildSettingsItem({
    required IconData icon, 
    required String title, 
    required String subtitle, 
    required VoidCallback onTap,
  }) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      leading: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: AppColors.primaryColor.withValues(alpha: 0.08),
          shape: BoxShape.circle,
        ),
        child: Icon(icon, color: AppColors.primaryColor, size: 22),
      ),
      title: Text(
        title,
        style: const TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 13,
          color: AppColors.textSecondary,
          fontFamily: 'Cairo',
        ),
      ),
      subtitle: Padding(
        padding: const EdgeInsets.only(top: 4),
        child: Text(
          subtitle,
          style: const TextStyle(
            color: AppColors.textPrimary,
            fontWeight: FontWeight.w700,
            fontSize: 16,
            fontFamily: 'Cairo',
          ),
        ),
      ),
      trailing: Icon(context.forwardIconIos, size: 16, color: Colors.grey),
      onTap: onTap,
    );
  }
}
