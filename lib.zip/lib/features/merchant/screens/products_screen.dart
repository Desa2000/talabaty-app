import 'package:talabaty_app/core/widgets/custom_image.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/providers/product_provider.dart';
import '../../../data/models/product_model.dart';

class MerchantProductsScreen extends StatefulWidget {
  const MerchantProductsScreen({super.key});

  @override
  State<MerchantProductsScreen> createState() => _MerchantProductsScreenState();
}

class _MerchantProductsScreenState extends State<MerchantProductsScreen> {
  String _selectedCategory = 'Ø§Ù„ÙƒÙ„';
  String _selectedAvailability = 'Ø§Ù„ÙƒÙ„';
  final TextEditingController _searchController = TextEditingController();

  final List<String> _categories = ['Ø§Ù„ÙƒÙ„', 'ÙˆØ¬Ø¨Ø§Øª Ø±Ø¦ÙŠØ³ÙŠØ©', 'Ù…Ø´ÙˆÙŠØ§Øª', 'Ø³Ù†Ø¯ÙˆØªØ´Ø§Øª', 'Ø¨ÙŠØªØ²Ø§', 'Ø¥Ø¶Ø§ÙØ§Øª', 'Ø§Ù„Ù…Ø´Ø±ÙˆØ¨Ø§Øª']; // Will be dynamic later
  final List<String> _availabilities = ['Ø§Ù„ÙƒÙ„', 'Ù…ØªØ§Ø­', 'ØºÙŠØ± Ù…ØªØ§Ø­', 'Ù…Ø®Ø²ÙˆÙ† Ù…Ù†Ø®ÙØ¶'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        title: const Text('Ø§Ù„Ù…Ù†ØªØ¬Ø§Øª'),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => context.push('/merchant/products/add'),
        backgroundColor: AppColors.primaryColor,
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text('Ø¥Ø¶Ø§ÙØ© Ù…Ù†ØªØ¬', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
      ),
      body: Column(
        children: [
          // Filters
          Container(
            color: Colors.white,
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                TextField(
                  controller: _searchController,
                  decoration: InputDecoration(
                    hintText: 'Ø§Ù„Ø¨Ø­Ø« Ø¹Ù† Ù…Ù†ØªØ¬...',
                    prefixIcon: const Icon(Icons.search),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16),
                  ),
                  onChanged: (v) => setState(() {}),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: DropdownButtonFormField<String>(
                        value: _selectedCategory,
                        decoration: InputDecoration(
                          labelText: 'Ø§Ù„ØªØµÙ†ÙŠÙ',
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                          contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                        ),
                        items: _categories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                        onChanged: (val) {
                          if (val != null) setState(() => _selectedCategory = val);
                        },
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: DropdownButtonFormField<String>(
                        value: _selectedAvailability,
                        decoration: InputDecoration(
                          labelText: 'Ø§Ù„ØªÙˆÙØ±',
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                          contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                        ),
                        items: _availabilities.map((a) => DropdownMenuItem(value: a, child: Text(a))).toList(),
                        onChanged: (val) {
                          if (val != null) setState(() => _selectedAvailability = val);
                        },
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          
          // List
          Expanded(
            child: Consumer<ProductProvider>(
              builder: (context, provider, child) {
                if (provider.isLoading) {
                  return const Center(child: CircularProgressIndicator());
                }

                final filteredProducts = provider.filterProducts(_selectedCategory, _selectedAvailability, _searchController.text);

                if (filteredProducts.isEmpty) {
                  return const Center(child: Text('Ù„Ø§ ØªÙˆØ¬Ø¯ Ù…Ù†ØªØ¬Ø§Øª ØªØ·Ø§Ø¨Ù‚ Ø§Ù„ÙØ±Ø².'));
                }

                return ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: filteredProducts.length,
                  itemBuilder: (context, index) {
                    final product = filteredProducts[index];
                    return _ProductCard(product: product);
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _ProductCard extends StatelessWidget {
  final ProductModel product;

  const _ProductCard({required this.product});

  @override
  Widget build(BuildContext context) {
    final bool isLowStock = product.stockQuantity > 0 && product.stockQuantity <= product.lowStockThreshold;
    final bool isOutOfStock = product.stockQuantity == 0;

    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: CustomImage(imagePath: product.image, fit: BoxFit.cover, width: 80, height: 80),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(product.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                      Text(product.category, style: const TextStyle(color: Colors.grey, fontSize: 12)),
                      const SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('${product.price} Ø¬.Ø³', style: const TextStyle(color: AppColors.primaryColor, fontWeight: FontWeight.bold)),
                          Text('Ø§Ù„Ù…Ø®Ø²ÙˆÙ†: ${product.stockQuantity}', style: TextStyle(color: isOutOfStock ? Colors.red : Colors.black, fontWeight: FontWeight.bold)),
                        ],
                      )
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            const Divider(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                // Badges
                Row(
                  children: [
                    if (isOutOfStock)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(color: Colors.red.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(8)),
                        child: const Text('ØºÙŠØ± Ù…ØªÙˆÙØ±', style: TextStyle(color: Colors.red, fontSize: 12, fontWeight: FontWeight.bold)),
                      )
                    else if (isLowStock)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(color: Colors.orange.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(8)),
                        child: const Text('Ù…Ø®Ø²ÙˆÙ† Ù…Ù†Ø®ÙØ¶', style: TextStyle(color: Colors.orange, fontSize: 12, fontWeight: FontWeight.bold)),
                      )
                    else
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(color: Colors.green.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(8)),
                        child: const Text('Ù…ØªØ§Ø­', style: TextStyle(color: Colors.green, fontSize: 12, fontWeight: FontWeight.bold)),
                      ),
                  ],
                ),
                // Actions
                Row(
                  children: [
                    Switch(
                      value: product.isAvailable,
                      activeColor: AppColors.primaryColor,
                      onChanged: (val) {
                        context.read<ProductProvider>().toggleAvailability(product.id, val);
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.edit, color: Colors.blue),
                      onPressed: () {
                         context.push('/merchant/products/edit/${product.id}');
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      onPressed: () {
                        // Delete logic
                        context.read<ProductProvider>().deleteProduct(product.id);
                      },
                    ),
                  ],
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}

