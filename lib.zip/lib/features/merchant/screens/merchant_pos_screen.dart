import 'package:flutter/material.dart';

class MerchantPOSScreen extends StatelessWidget {
  const MerchantPOSScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('نقطة البيع (POS)')),
      body: const Center(child: Text('جاري برمجة شاشة نقاط البيع...')),
    );
  }
}
