import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';
import 'package:go_router/go_router.dart';
import '../../../core/constants/app_colors.dart';

class MapPickerScreen extends StatefulWidget {
  const MapPickerScreen({super.key});

  @override
  State<MapPickerScreen> createState() => _MapPickerScreenState();
}

class _MapPickerScreenState extends State<MapPickerScreen> {
  final MapController _mapController = MapController();
  
  // Default to Khartoum coordinates
  LatLng _currentCenter = const LatLng(15.5007, 32.5599); 
  bool _isLoading = true;
  bool _isMapReady = false;
  String _currentAddressText = "جاري تحديد الموقع...";

  @override
  void initState() {
    super.initState();
    _determinePosition();
  }

  Future<void> _determinePosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      _showLocationWarning('خدمات الموقع (GPS) مغلقة، يرجى تفعيلها من إعدادات الهاتف.');
      _finishLoading();
      return;
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        _showLocationWarning('التطبيق يحتاج لصلاحية الموقع لتحديد عنوان التوصيل بدقة.');
        _finishLoading();
        return;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      _showLocationWarning('صلاحية الموقع مرفوضة دائماً. يرجى تفعيلها من إعدادات التطبيق.');
      _finishLoading();
      return;
    }

    try {
      final position = await Geolocator.getCurrentPosition(
        timeLimit: const Duration(seconds: 10),
      );
      if (mounted) {
        setState(() {
          _currentCenter = LatLng(position.latitude, position.longitude);
          _isLoading = false;
          _updateAddressText();
        });
        
        if (_isMapReady) {
          _mapController.move(_currentCenter, 15.0);
        }
      }
    } catch (e) {
      _showLocationWarning('فشل في الحصول على الموقع الجغرافي. يرجى التأكد من قوة إشارة الـ GPS أو تحديد الموقع يدوياً.');
      _finishLoading();
    }
  }

  void _finishLoading() {
    setState(() {
      _isLoading = false;
      _updateAddressText();
    });
  }

  void _showLocationWarning(String message) {
    if (!mounted) return;
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('تنبيه الموقع', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.red)),
        content: Text(message),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('حسناً'),
          )
        ],
      ),
    );
  }

  void _updateAddressText() {
    setState(() {
      _currentAddressText = "موقع مخصص (${_currentCenter.latitude.toStringAsFixed(4)}, ${_currentCenter.longitude.toStringAsFixed(4)})";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('حدد موقع التوصيل'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
      ),
      body: Stack(
        children: [
          // The Map
          FlutterMap(
            mapController: _mapController,
            options: MapOptions(
              initialCenter: _currentCenter,
              initialZoom: 15.0,
              onMapReady: () {
                _isMapReady = true;
                if (!_isLoading) {
                  _mapController.move(_currentCenter, 15.0);
                }
              },
              onPositionChanged: (position, hasGesture) {
                if (hasGesture && position.center != null) {
                  setState(() {
                    _currentCenter = position.center!;
                  });
                }
              },
              onMapEvent: (event) {
                if (event is MapEventMoveEnd) {
                  _updateAddressText();
                }
              },
            ),
            children: [
              TileLayer(
                urlTemplate: 'https://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}',
                userAgentPackageName: 'com.example.talabaty_app',
              ),
            ],
          ),
          
          // The Fixed Center Pin (Floating above the map)
          Center(
            child: Padding(
              padding: const EdgeInsets.only(bottom: 40.0), // Adjust to make the pin point exactly at center
              child: const Icon(
                Icons.location_on, 
                size: 50, 
                color: AppColors.primaryColor,
              ),
            ),
          ),
          
          // My Location Button
          Positioned(
            bottom: 150,
            right: 16,
            child: FloatingActionButton(
              heroTag: 'myLocationBtn',
              backgroundColor: Colors.white,
              foregroundColor: AppColors.primaryColor,
              onPressed: () {
                setState(() => _isLoading = true);
                _determinePosition();
              },
              child: _isLoading 
                  ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.my_location),
            ),
          ),

          // Search Bar Overlay
          Positioned(
            top: 16,
            left: 16,
            right: 16,
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.1), blurRadius: 10)],
              ),
              child: const TextField(
                decoration: InputDecoration(
                  hintText: 'ابحث عن شارع أو منطقة...',
                  prefixIcon: Icon(Icons.search, color: AppColors.primaryColor),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                ),
              ),
            ),
          ),

          // Bottom Info Card
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
                boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.1), blurRadius: 10, offset: const Offset(0, -5))],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('موقع التوصيل المحدد', style: TextStyle(color: AppColors.textSecondary, fontSize: 14)),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      const Icon(Icons.location_on, color: AppColors.primaryColor),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          _isLoading ? 'جاري التحديد...' : _currentAddressText, 
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primaryColor,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      onPressed: () {
                        // Return the selected location
                        context.pop(_currentCenter);
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم تأكيد الموقع بنجاح!')));
                      },
                      child: const Text('تأكيد الموقع', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Loading overlay
          if (_isLoading)
            Container(
              color: Colors.white.withValues(alpha: 0.7),
              child: const Center(child: CircularProgressIndicator(color: AppColors.primaryColor)),
            ),
        ],
      ),
      floatingActionButton: Padding(
        padding: const EdgeInsets.only(bottom: 160.0),
        child: FloatingActionButton(
          backgroundColor: Colors.white,
          child: const Icon(Icons.my_location, color: AppColors.primaryColor),
          onPressed: () {
            _determinePosition();
          },
        ),
      ),
    );
  }
}
