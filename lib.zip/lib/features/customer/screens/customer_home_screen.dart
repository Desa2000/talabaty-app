import 'package:talabaty_app/core/widgets/custom_image.dart';
import 'package:talabaty_app/core/utils/directional_extensions.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:talabaty_app/core/providers/data_provider.dart';
import 'package:talabaty_app/core/providers/auth_provider.dart';
import 'package:talabaty_app/core/providers/address_provider.dart';
import 'package:talabaty_app/core/providers/notification_provider.dart';
import 'package:talabaty_app/core/constants/app_colors.dart';
import 'package:talabaty_app/data/models/store_model.dart';

class CustomerHomeScreen extends StatelessWidget {
  const CustomerHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    try {
      final stores = context.select<DataProvider, List<StoreModel>>((dp) => dp.stores);
      final authProvider = context.watch<AuthProvider>();
      final currentUser = authProvider.currentUser;
      final userName = (currentUser != null && currentUser.name.trim().isNotEmpty)
          ? currentUser.name.trim().split(' ').first
          : 'ضيف';

      return Scaffold(
        backgroundColor: AppColors.backgroundLight,
        body: SafeArea(
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildPremiumHeader(context, userName),
                _buildSearchBar(context),
                _buildBanners(),
                _buildCategoriesHeader(),
                _buildHorizontalCategories(context),
                _buildNearbyRestaurants(context, stores),
                const SizedBox(height: 32),
              ],
            ),
          ),
        ),
      );
    } catch (e, stack) {
      return Scaffold(
        body: SafeArea(
          child: Container(
            color: const Color(0xFFFFEBEE), // light red
            padding: const EdgeInsets.all(16),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Error in CustomerHomeScreen:',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Colors.red),
                  ),
                  const SizedBox(height: 8),
                  Text('$e', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.black)),
                  const SizedBox(height: 8),
                  Text('$stack', style: const TextStyle(fontSize: 11, color: Colors.black54)),
                ],
              ),
            ),
          ),
        ),
      );
    }
  }

  Widget _buildPremiumHeader(BuildContext context, String userName) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'أهلاً، $userName 👋',
                  style: const TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    fontFamily: 'Cairo',
                  ),
                ),
                const SizedBox(height: 6),
                GestureDetector(
                  onTap: () => context.push('/customer/address'),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(color: AppColors.borderGray.withValues(alpha: 0.8), width: 1),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.02),
                          blurRadius: 6,
                          offset: const Offset(0, 2),
                        )
                      ],
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.location_on_rounded, color: AppColors.primaryColor, size: 16),
                        const SizedBox(width: 4),
                        Consumer<AddressProvider>(
                          builder: (context, addressProvider, _) {
                            final selectedAddress = addressProvider.selectedAddress;
                            final addressText = selectedAddress != null
                                ? '${selectedAddress.city} - ${selectedAddress.area}'
                                : 'إضافة موقع (اضغط)';
                            return Text(
                              addressText,
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 12,
                                color: AppColors.textPrimary,
                                fontFamily: 'Cairo',
                              ),
                            );
                          },
                        ),
                        const SizedBox(width: 2),
                        const Icon(Icons.keyboard_arrow_down_rounded, color: AppColors.textSecondary, size: 16),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Consumer<NotificationProvider>(
            builder: (context, notifProvider, _) {
              return Stack(
                clipBehavior: Clip.none,
                children: [
                  Container(
                    height: 48,
                    width: 48,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                      border: Border.all(color: AppColors.borderGray.withValues(alpha: 0.8)),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.04),
                          blurRadius: 12,
                          offset: const Offset(0, 4),
                        )
                      ],
                    ),
                    child: IconButton(
                      icon: const Icon(Icons.notifications_outlined, color: AppColors.textPrimary, size: 22),
                      onPressed: () => context.push('/customer/notifications'),
                    ),
                  ),
                  if (notifProvider.hasUnread)
                    Positioned(
                      right: 2,
                      top: 2,
                      child: Container(
                        width: 10,
                        height: 10,
                        decoration: BoxDecoration(
                          color: Colors.red,
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white, width: 2),
                        ),
                      ).animate(onPlay: (controller) => controller.repeat(reverse: true))
                       .scale(begin: const Offset(0.8, 0.8), end: const Offset(1.2, 1.2), duration: 800.ms),
                    ),
                ],
              );
            },
          )
        ],
      ),
    );
  }

  Widget _buildSearchBar(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: GestureDetector(
        onTap: () => context.push('/customer/search'),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.primaryColor.withValues(alpha: 0.1), width: 1.5),
            boxShadow: [
              BoxShadow(
                color: AppColors.primaryColor.withValues(alpha: 0.04),
                blurRadius: 16,
                offset: const Offset(0, 6),
              )
            ],
          ),
          child: AbsorbPointer(
            child: TextField(
              decoration: InputDecoration(
                hintText: 'عن ماذا تبحث اليوم؟',
                hintStyle: TextStyle(color: Colors.grey.shade400, fontSize: 14, fontFamily: 'Cairo'),
                prefixIcon: const Icon(Icons.search_rounded, color: AppColors.primaryColor, size: 24),
                filled: true,
                fillColor: Colors.transparent,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: BorderSide.none,
                ),
                contentPadding: const EdgeInsets.symmetric(vertical: 16),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBanners() {
    return Container(
      height: 165,
      margin: const EdgeInsets.symmetric(vertical: 16),
      child: PageView(
        controller: PageController(viewportFraction: 0.9),
        physics: const BouncingScrollPhysics(),
        children: [
          _buildSingleBanner(
            title: 'توصيل مجاني\nلأول 3 طلبات',
            subtitle: 'خصم حصري 🔥',
            color1: AppColors.primaryColor,
            color2: const Color(0xFFFF8C00),
            icon: Icons.delivery_dining_rounded,
          ),
          _buildSingleBanner(
            title: 'وجبات عائلية\nبنصف السعر',
            subtitle: 'عروض الويكند 🍕',
            color1: const Color(0xFF2E7D32),
            color2: const Color(0xFF4CAF50),
            icon: Icons.fastfood_rounded,
          ),
        ],
      ),
    ).animate().fade(duration: 500.ms).slideY(begin: 0.08, end: 0, curve: Curves.easeOutQuad);
  }

  Widget _buildSingleBanner({
    required String title,
    required String subtitle,
    required Color color1,
    required Color color2,
    required IconData icon,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: LinearGradient(
          colors: [color1, color2],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: color1.withValues(alpha: 0.45),
            blurRadius: 24,
            spreadRadius: 0,
            offset: const Offset(0, 10),
          ),
          BoxShadow(
            color: color2.withValues(alpha: 0.2),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: Stack(
          children: [
            // Background decorative circles
            Positioned(
              right: -20,
              bottom: -20,
              child: CircleAvatar(
                radius: 90,
                backgroundColor: Colors.white.withValues(alpha: 0.08),
              ),
            ),
            Positioned(
              right: 10,
              top: -30,
              child: CircleAvatar(
                radius: 50,
                backgroundColor: Colors.white.withValues(alpha: 0.05),
              ),
            ),
            // ✨ Shimmer sweep highlight — diagonal gleam strip
            Positioned(
              top: -30,
              left: 30,
              child: Transform.rotate(
                angle: 0.55,
                child: Container(
                  width: 28,
                  height: 220,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.white.withValues(alpha: 0.0),
                        Colors.white.withValues(alpha: 0.18),
                        Colors.white.withValues(alpha: 0.0),
                      ],
                    ),
                  ),
                ),
              )
              .animate(onPlay: (c) => c.repeat())
              .moveX(
                begin: -60,
                end: 340,
                duration: 2400.ms,
                delay: 800.ms,
                curve: Curves.easeInOut,
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(22),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.22),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: Colors.white.withValues(alpha: 0.3),
                              width: 1,
                            ),
                          ),
                          child: Text(
                            subtitle,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Cairo',
                            ),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Text(
                          title,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 22,
                            fontWeight: FontWeight.w900,
                            height: 1.25,
                            fontFamily: 'Cairo',
                          ),
                        ),
                      ],
                    ),
                  ),
                  Hero(
                    tag: 'banner_icon_$title',
                    child: Icon(
                      icon,
                      size: 85,
                      color: Colors.white.withValues(alpha: 0.9),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCategoriesHeader() {
    return const Padding(
      padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
      child: Text(
        'اكتشف الأقسام',
        style: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
          color: AppColors.textPrimary,
          fontFamily: 'Cairo',
        ),
      ),
    );
  }

  Widget _buildHorizontalCategories(BuildContext context) {
    return SizedBox(
      height: 115,
      child: ListView(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: 10),
        children: [
          _buildSquareCategoryCard(
            context,
            icon: Icons.restaurant_rounded,
            title: 'المطاعم',
            color: const Color(0xFFFF6A00),
            onTap: () => context.push('/customer/stores/restaurant'),
          ),
          _buildSquareCategoryCard(
            context,
            icon: Icons.shopping_basket_rounded,
            title: 'سوبرماركت',
            color: const Color(0xFF2E7D32),
            onTap: () => context.push('/customer/stores/supermarket'),
          ),
          _buildSquareCategoryCard(
            context,
            icon: Icons.local_pharmacy_rounded,
            title: 'صيدلية',
            color: const Color(0xFF007AFF),
            onTap: () => context.push('/customer/stores/pharmacy'),
          ),
          _buildSquareCategoryCard(
            context,
            icon: Icons.card_giftcard_rounded,
            title: 'هدايا',
            color: const Color(0xFF9C27B0),
            onTap: () => context.push('/customer/stores/gift'),
          ),
        ],
      ),
    ).animate().fade(duration: 500.ms, delay: 150.ms).slideY(begin: 0.08, end: 0, curve: Curves.easeOutQuad);
  }

  Widget _buildSquareCategoryCard(
    BuildContext context, {
    required IconData icon,
    required String title,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 88,
        margin: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: color.withValues(alpha: 0.08), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.03),
              blurRadius: 10,
              offset: const Offset(0, 4),
            )
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.08),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: color, size: 26),
            ),
            const SizedBox(height: 8),
            Text(
              title,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 12,
                color: AppColors.textPrimary,
                fontFamily: 'Cairo',
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNearbyRestaurants(BuildContext context, List stores) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 24, 16, 12),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'الأقرب إليك',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textPrimary,
                  fontFamily: 'Cairo',
                ),
              ),
              TextButton(
                onPressed: () => context.push('/customer/stores/restaurant'),
                child: Row(
                  children: [
                    const Text(
                      'عرض الكل',
                      style: TextStyle(
                        color: AppColors.primaryColor,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Cairo',
                      ),
                    ),
                    Icon(context.chevronRight, color: AppColors.primaryColor, size: 20),
                  ],
                ),
              ),
            ],
          ),
        ),
        stores.isEmpty
            ? Container(
                width: double.infinity,
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppColors.borderGray.withValues(alpha: 0.5)),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.02),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    )
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.storefront_outlined, size: 48, color: Colors.grey[400]),
                    const SizedBox(height: 12),
                    const Text(
                      'لا توجد مطاعم متوفرة حالياً',
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, fontFamily: 'Cairo', color: AppColors.textPrimary),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'سيتم إضافة مطاعم قريباً لخدمتكم',
                      style: TextStyle(fontSize: 12, fontFamily: 'Cairo', color: Colors.grey[600]),
                    ),
                  ],
                ),
              )
            : ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: stores.length > 5 ? 5 : stores.length,
          itemBuilder: (context, index) {
            final store = stores[index];
            return GestureDetector(
              onTap: () => context.push('/customer/store/${store.id}'),
              child: Container(
                margin: const EdgeInsets.only(bottom: 18),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.borderGray.withValues(alpha: 0.4), width: 1),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.06),
                      blurRadius: 20,
                      spreadRadius: 0,
                      offset: const Offset(0, 6),
                    ),
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.03),
                      blurRadius: 6,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Stack(
                      children: [
                        Hero(
                          tag: 'store_image_${store.id}',
                          child: ClipRRect(
                            borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
                            child: CustomImage(
                              imagePath: store.coverImage ?? store.logo ?? 'https://via.placeholder.com/350x150',
                              fit: BoxFit.cover,
                              height: 165,
                              width: double.infinity,
                            ),
                          ),
                        ),
                        // Soft gradient overlay on image
                        Positioned.fill(
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
                              gradient: LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [
                                  Colors.black.withValues(alpha: 0.15),
                                  Colors.transparent,
                                  Colors.black.withValues(alpha: 0.3),
                                ],
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          top: 14,
                          left: 14,
                          child: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: const BoxDecoration(
                              color: Colors.white,
                              shape: BoxShape.circle,
                            ),
                            child: const Icon(Icons.favorite_border_rounded, color: Colors.grey, size: 20),
                          ),
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.all(18),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(
                                child: Text(
                                  store.name,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 18,
                                    color: AppColors.textPrimary,
                                    fontFamily: 'Cairo',
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                decoration: BoxDecoration(
                                  color: Colors.amber.withValues(alpha: 0.12),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Row(
                                  children: [
                                    const Icon(Icons.star_rounded, color: Colors.amber, size: 18),
                                    const SizedBox(width: 4),
                                    Text(
                                      '${store.rating}',
                                      style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: Colors.amber,
                                        fontFamily: 'Cairo',
                                        fontSize: 13,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 6),
                          Text(
                            store.area,
                            style: const TextStyle(
                              color: AppColors.textSecondary,
                              fontSize: 14,
                              fontFamily: 'Cairo',
                            ),
                          ),
                          const SizedBox(height: 14),
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: AppColors.backgroundLight,
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: Row(
                              children: [
                                _buildInfoChip(Icons.access_time_rounded, store.preparationTime),
                                const SizedBox(width: 24),
                                _buildInfoChip(Icons.delivery_dining_rounded, '${store.deliveryFee.toInt()} ج.س'),
                              ],
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ).animate().fade(duration: 400.ms, delay: Duration(milliseconds: 70 * index)).slideY(begin: 0.08, end: 0);
          },
        ),
      ],
    );
  }

  Widget _buildInfoChip(IconData icon, String text) {
    return Row(
      children: [
        Icon(icon, color: AppColors.primaryColor, size: 18),
        const SizedBox(width: 6),
        Text(
          text,
          style: const TextStyle(
            color: AppColors.textPrimary,
            fontSize: 13,
            fontWeight: FontWeight.bold,
            fontFamily: 'Cairo',
          ),
        ),
      ],
    );
  }
}



