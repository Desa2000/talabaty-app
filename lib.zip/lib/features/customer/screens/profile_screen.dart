import 'package:flutter/material.dart';
import 'package:talabaty_app/core/utils/directional_extensions.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/providers/auth_provider.dart';
import '../../../core/providers/address_provider.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final authProvider = context.watch<AuthProvider>();
    final addressProvider = context.watch<AddressProvider>();
    final user = authProvider.currentUser;
    final addresses = addressProvider.addresses;

    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      appBar: AppBar(
        title: const Text('الملف الشخصي'),
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              width: double.infinity,
              color: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 32),
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: AppColors.primaryColor.withValues(alpha: 0.2), width: 4),
                    ),
                    child: const CircleAvatar(
                      radius: 50,
                      backgroundColor: AppColors.accentCream,
                      child: Icon(Icons.person, size: 50, color: AppColors.primaryColor),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    user?.name ?? 'مستخدم',
                    style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    user?.phone ?? '',
                    style: const TextStyle(fontSize: 16, color: Colors.grey),
                  ),
                ],
              ),
            ),
            
            const SizedBox(height: 24),
            
            if (user != null) ...[
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('العناوين المحفوظة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    TextButton(
                      onPressed: () => context.push('/customer/address'),
                      child: const Text('إدارة العناوين', style: TextStyle(color: AppColors.primaryColor, fontWeight: FontWeight.bold)),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Card(
                  elevation: 0,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  child: addresses.isEmpty
                      ? const Padding(
                          padding: EdgeInsets.all(24.0),
                          child: Center(child: Text('لا توجد عناوين محفوظة', style: TextStyle(color: Colors.grey))),
                        )
                      : ListView.separated(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: addresses.length,
                          separatorBuilder: (context, index) => const Divider(height: 1, indent: 60),
                          itemBuilder: (context, index) {
                            final address = addresses[index];
                            return ListTile(
                              leading: Container(
                                padding: const EdgeInsets.all(8),
                                decoration: BoxDecoration(color: AppColors.accentCream, borderRadius: BorderRadius.circular(8)),
                                child: const Icon(Icons.location_on, color: AppColors.primaryColor),
                              ),
                              title: Text(address.title, style: const TextStyle(fontWeight: FontWeight.bold)),
                              subtitle: Text('${address.area} - ${address.street}', style: const TextStyle(fontSize: 12)),
                              trailing: IconButton(
                                icon: const Icon(Icons.delete_outline, color: Colors.red),
                                onPressed: () {
                                  addressProvider.removeAddress(address.id);
                                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم حذف العنوان')));
                                },
                              ),
                            );
                          },
                        ),
                ),
              ),
            ],

            const SizedBox(height: 24),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.03), blurRadius: 10, offset: const Offset(0, 4))],
                ),
                child: Column(
                  children: [
                    _buildMenuItem(Icons.receipt_long, 'طلباتي', Colors.blue, () => context.push('/customer/orders')),
                    const Divider(height: 1, indent: 64),
                    _buildMenuItem(Icons.favorite_border, 'المفضلة', Colors.pink, () => context.push('/customer/favorites')),
                    const Divider(height: 1, indent: 64),
                    _buildMenuItem(Icons.credit_card, 'طرق الدفع', Colors.green, () => context.push('/customer/payment-methods')),
                    const Divider(height: 1, indent: 64),
                    _buildMenuItem(Icons.settings_outlined, 'الإعدادات', Colors.orange, () => context.push('/customer/settings')),
                  ],
                ),
              ),
            ),
            
            const SizedBox(height: 24),
            
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.03), blurRadius: 10, offset: const Offset(0, 4))],
                ),
                child: _buildMenuItem(Icons.logout, 'تسجيل الخروج', AppColors.error, () {
                  authProvider.logout();
                  if (context.mounted) context.go('/login');
                }, isLogout: true),
              ),
            ),

            const SizedBox(height: 32),
            const Text('طلباتي\nإصدار 1.0.0', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey, fontSize: 12)),
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }

  Widget _buildMenuItem(IconData icon, String title, Color iconColor, VoidCallback onTap, {bool isLogout = false}) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: iconColor.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: iconColor, size: 22),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Text(
                  title,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: isLogout ? FontWeight.bold : FontWeight.w600,
                    color: isLogout ? iconColor : AppColors.textPrimary,
                  ),
                ),
              ),
              if (!isLogout)
                Icon(Icons.arrow_forward_ios_rounded, size: 16, color: Colors.grey.shade400),
            ],
          ),
        ),
      ),
    );
  }
}
