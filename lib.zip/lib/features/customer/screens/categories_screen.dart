import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/providers/data_provider.dart';
import '../../../core/constants/enums.dart';

class CategoriesScreen extends StatelessWidget {
  const CategoriesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final dataProvider = context.watch<DataProvider>();
    final stores = dataProvider.stores;

    final restaurantCount = stores.where((s) => s.type == StoreType.restaurant).length;
    final supermarketCount = stores.where((s) => s.type == StoreType.supermarket).length;
    final pharmacyCount = stores.where((s) => s.type == StoreType.pharmacy).length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('التصنيفات'),
      ),
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _buildPremiumCategoryCard(
              context,
              title: 'المطاعم',
              description: 'أكلات ووجبات من أقرب المطاعم',
              icon: Icons.restaurant,
              storeCount: restaurantCount,
              onTap: () => context.push('/customer/stores/restaurant'),
            ),
            const SizedBox(height: 16),
            _buildPremiumCategoryCard(
              context,
              title: 'السوبرماركتات',
              description: 'منتجات يومية ومواد غذائية',
              icon: Icons.shopping_cart,
              storeCount: supermarketCount,
              onTap: () => context.push('/customer/stores/supermarket'),
            ),
            const SizedBox(height: 16),
            _buildPremiumCategoryCard(
              context,
              title: 'الصيدليات',
              description: 'أدوية ومنتجات صحية',
              icon: Icons.local_pharmacy,
              storeCount: pharmacyCount,
              onTap: () => context.push('/customer/stores/pharmacy'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPremiumCategoryCard(BuildContext context, {
    required String title,
    required String description,
    required IconData icon,
    required int storeCount,
    required VoidCallback onTap,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
        ],
        border: Border.all(color: AppColors.borderGray, width: 1),
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppColors.accentCream,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Icon(icon, size: 40, color: AppColors.primaryColor),
                ),
                const SizedBox(width: 20),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
                      const SizedBox(height: 4),
                      Text(description, style: const TextStyle(fontSize: 14, color: AppColors.textSecondary)),
                      const SizedBox(height: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: AppColors.backgroundLight,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          '$storeCount متوفر',
                          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: AppColors.primaryColor),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const Divider(height: 1),
          InkWell(
            onTap: onTap,
            borderRadius: const BorderRadius.vertical(bottom: Radius.circular(20)),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 16),
              alignment: Alignment.center,
              child: const Text(
                'تصفح الآن',
                style: TextStyle(
                  color: AppColors.primaryColor,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
