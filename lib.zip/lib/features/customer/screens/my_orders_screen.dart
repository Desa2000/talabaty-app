import 'package:talabaty_app/core/widgets/custom_image.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import '../../../core/providers/data_provider.dart';
import '../../../core/providers/auth_provider.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/constants/enums.dart';
import 'package:intl/intl.dart';
import '../../../data/models/order_model.dart';
import '../../../data/models/store_model.dart';
class MyOrdersScreen extends StatefulWidget {
  const MyOrdersScreen({super.key});

  @override
  State<MyOrdersScreen> createState() => _MyOrdersScreenState();
}

class _MyOrdersScreenState extends State<MyOrdersScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.read<AuthProvider>();
    final myOrders = context.select<DataProvider, List<OrderModel>>(
      (dp) => dp.getOrdersForCustomer(auth.currentUser?.id ?? '')
    );
    final stores = context.select<DataProvider, List<StoreModel>>((dp) => dp.stores);

    final activeOrders = myOrders.where((o) =>
        o.status != OrderStatus.delivered && o.status != OrderStatus.cancelled && o.status != OrderStatus.rejectedByMerchant).toList();
    final pastOrders = myOrders.where((o) =>
        o.status == OrderStatus.delivered || o.status == OrderStatus.cancelled || o.status == OrderStatus.rejectedByMerchant).toList();

    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      appBar: AppBar(
        title: const Text('طلباتي', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: AppColors.primaryColor,
          labelColor: AppColors.primaryColor,
          unselectedLabelColor: Colors.grey,
          indicatorWeight: 3,
          labelStyle: const TextStyle(fontWeight: FontWeight.bold),
          tabs: [
            Tab(text: 'نشطة (${activeOrders.length})'),
            Tab(text: 'السابقة (${pastOrders.length})'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildOrdersList(context, stores, activeOrders, isActive: true),
          _buildOrdersList(context, stores, pastOrders, isActive: false),
        ],
      ),
    );
  }

  Widget _buildOrdersList(BuildContext context, List<StoreModel> stores, List<OrderModel> orders, {required bool isActive}) {
    if (orders.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(isActive ? Icons.receipt_long_outlined : Icons.history, size: 80, color: Colors.grey.shade300),
            const SizedBox(height: 16),
            Text(
              isActive ? 'لا توجد طلبات نشطة' : 'لا توجد طلبات سابقة',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.grey),
            ),
            const SizedBox(height: 8),
            const Text('سيتم عرض طلباتك هنا', style: TextStyle(color: Colors.grey)),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: orders.length,
      itemBuilder: (context, index) {
        final order = orders[index];
        // Safe store lookup with fallback
        final store = stores.firstWhere(
          (s) => s.id == order.storeId,
          orElse: () => stores.isNotEmpty ? stores.first : StoreModel(id: 'dummy', ownerId: '', name: 'متجر غير معروف', type: StoreType.restaurant, phone: '', area: '', street: '', landmark: '', latitude: 0, longitude: 0, openingTime: '', closingTime: '', preparationTime: '', minimumOrder: 0, deliveryFee: 0, status: '', rating: 0, ratingCount: 0),
        );
        final dateStr = DateFormat('dd/MM/yyyy hh:mm a').format(order.createdAt);

        Color statusColor = Colors.grey;
        IconData statusIcon = Icons.info_outline;
        switch (order.status) {
          case OrderStatus.pending:
            statusColor = Colors.orange;
            statusIcon = Icons.hourglass_empty;
            break;
          case OrderStatus.acceptedByMerchant:
          case OrderStatus.preparing:
            statusColor = Colors.blue;
            statusIcon = Icons.restaurant;
            break;
          case OrderStatus.readyForPickup:
          case OrderStatus.searchingCourier:
          case OrderStatus.assignedToCourier:
            statusColor = Colors.purple;
            statusIcon = Icons.check_circle_outline;
            break;
          case OrderStatus.courierGoingToStore:
          case OrderStatus.courierArrivedStore:
          case OrderStatus.pickedUp:
          case OrderStatus.onTheWay:
          case OrderStatus.courierArrivedCustomer:
            statusColor = Colors.teal;
            statusIcon = Icons.delivery_dining;
            break;
          case OrderStatus.delivered:
            statusColor = Colors.green;
            statusIcon = Icons.check_circle;
            break;
          case OrderStatus.rejectedByMerchant:
          case OrderStatus.cancelled:
            statusColor = Colors.red;
            statusIcon = Icons.cancel;
            break;
        }

        return Container(
          margin: const EdgeInsets.only(bottom: 16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 10, offset: const Offset(0, 4))],
          ),
          child: InkWell(
            borderRadius: BorderRadius.circular(20),
            onTap: () => context.push('/customer/order-tracking/${order.id}'),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: CustomImage(
                          imagePath: store.logo ?? store.coverImage ?? '', 
                          fit: BoxFit.cover,
                          width: 56,
                          height: 56,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(store.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                            const SizedBox(height: 4),
                            Text(dateStr, style: const TextStyle(color: Colors.grey, fontSize: 12)),
                          ],
                        ),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text('${order.total} Ø¬.Ø³', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: AppColors.primaryColor)),
                          const SizedBox(height: 4),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(color: statusColor.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(8)),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(statusIcon, color: statusColor, size: 12),
                                const SizedBox(width: 4),
                                Text(order.status.arabicLabel, style: TextStyle(color: statusColor, fontSize: 11, fontWeight: FontWeight.bold)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  if (order.items.isNotEmpty) ...[
                    const SizedBox(height: 12),
                    const Divider(height: 1),
                    const SizedBox(height: 12),
                    Text(
                      order.items.map((i) => '${i.quantity}x ${i.product.name}').join(' â€¢ '),
                      style: const TextStyle(color: Colors.grey, fontSize: 13),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                  if (!isActive && order.status == OrderStatus.delivered) ...[
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        icon: const Icon(Icons.refresh, size: 16),
                        label: const Text('Ø¥Ø¹Ø§Ø¯Ø© Ø§Ù„Ø·Ù„Ø¨'),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: AppColors.primaryColor,
                          side: const BorderSide(color: AppColors.primaryColor),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        onPressed: () => context.push('/customer/store/${order.storeId}'),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

