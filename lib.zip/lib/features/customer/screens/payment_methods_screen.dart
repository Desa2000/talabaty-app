import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/providers/payment_provider.dart';

class PaymentMethodsScreen extends StatelessWidget {
  const PaymentMethodsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final paymentProvider = context.watch<PaymentProvider>();
    final cards = paymentProvider.cards;

    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      appBar: AppBar(
        title: const Text('طرق الدفع'),
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'البطاقات المحفوظة',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            
            if (cards.isEmpty)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.borderGray),
                ),
                child: const Center(
                  child: Text('لا توجد بطاقات محفوظة. الرجاء إضافة بطاقة جديدة.', style: TextStyle(color: Colors.grey)),
                ),
              )
            else
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: cards.length,
                itemBuilder: (context, index) {
                  final card = cards[index];
                  final isSelected = paymentProvider.selectedCardId == card.id;
                  
                  return _buildCreditCard(context, card, isSelected);
                },
              ),
            
            const SizedBox(height: 32),
            const Text(
              'طرق أخرى',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            
            // Cash on Delivery Option
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: paymentProvider.selectedCardId == null ? AppColors.primaryColor : AppColors.borderGray,
                  width: paymentProvider.selectedCardId == null ? 2 : 1,
                ),
                boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.03), blurRadius: 10, offset: const Offset(0, 4))],
              ),
              child: ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(color: AppColors.accentCream, borderRadius: BorderRadius.circular(8)),
                  child: const Icon(Icons.money, color: AppColors.primaryColor),
                ),
                title: const Text('الدفع عند الاستلام', style: TextStyle(fontWeight: FontWeight.bold)),
                subtitle: const Text('الدفع نقداً للمندوب عند وصول الطلب', style: TextStyle(fontSize: 12)),
                trailing: paymentProvider.selectedCardId == null 
                    ? const Icon(Icons.check_circle, color: AppColors.primaryColor)
                    : null,
                onTap: () {
                  // Pass null card ID to fallback to Cash on Delivery
                  // We can select null by pass an empty ID or using a dedicated method
                  paymentProvider.selectCard('');
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddCardBottomSheet(context),
        backgroundColor: AppColors.primaryColor,
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text('إضافة بطاقة جديدة', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
      ),
    );
  }

  Widget _buildCreditCard(BuildContext context, PaymentCard card, bool isSelected) {
    final gradient = card.cardType == 'VISA' 
        ? const LinearGradient(colors: [Color(0xFF1E3C72), Color(0xFF2A5298)])
        : const LinearGradient(colors: [Color(0xFFED213A), Color(0xFF93291E)]);

    return GestureDetector(
      onTap: () => context.read<PaymentProvider>().selectCard(card.id),
      child: Container(
        height: 200,
        width: double.infinity,
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          gradient: gradient,
          border: isSelected ? Border.all(color: Colors.white, width: 3) : null,
          boxShadow: [
            BoxShadow(
              color: (card.cardType == 'VISA' ? const Color(0xFF1E3C72) : const Color(0xFFED213A)).withValues(alpha: 0.4),
              blurRadius: 15,
              offset: const Offset(0, 8),
            )
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    const Icon(Icons.credit_card, color: Colors.white, size: 32),
                    if (isSelected) ...[
                      const SizedBox(width: 8),
                      const Icon(Icons.check_circle, color: Colors.white, size: 20),
                    ]
                  ],
                ),
                Row(
                  children: [
                    Text(card.cardType, style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold, fontStyle: FontStyle.italic)),
                    const SizedBox(width: 8),
                    IconButton(
                      icon: const Icon(Icons.delete_outline, color: Colors.white70, size: 20),
                      onPressed: () {
                        context.read<PaymentProvider>().removeCard(card.id);
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم حذف البطاقة بنجاح')));
                      },
                    )
                  ],
                ),
              ],
            ),
            Text(
              card.cardNumber,
              style: const TextStyle(color: Colors.white, fontSize: 22, letterSpacing: 2),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Card Holder', style: TextStyle(color: Colors.white70, fontSize: 10)),
                    Text(card.holderName, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Expires', style: TextStyle(color: Colors.white70, fontSize: 10)),
                    Text(card.expiryDate, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showAddCardBottomSheet(BuildContext context) {
    final formKey = GlobalKey<FormState>();
    final holderController = TextEditingController();
    final numberController = TextEditingController();
    final expiryController = TextEditingController();
    final cvvController = TextEditingController();
    String cardType = 'VISA';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setModalState) => Container(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
            top: 24,
            left: 24,
            right: 24,
          ),
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
          ),
          child: SingleChildScrollView(
            child: Form(
              key: formKey,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Container(
                      width: 50,
                      height: 5,
                      decoration: const BoxDecoration(color: Colors.grey, borderRadius: BorderRadius.all(Radius.circular(10))),
                    ),
                  ),
                  const SizedBox(height: 24),
                  const Text('إضافة بطاقة دفع جديدة', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 24),
                  
                  // Card Type Selector
                  Row(
                    children: [
                      Expanded(
                        child: ChoiceChip(
                          label: const Text('VISA'),
                          selected: cardType == 'VISA',
                          onSelected: (val) => setModalState(() => cardType = 'VISA'),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ChoiceChip(
                          label: const Text('MasterCard'),
                          selected: cardType == 'MasterCard',
                          onSelected: (val) => setModalState(() => cardType = 'MasterCard'),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  
                  TextFormField(
                    controller: holderController,
                    decoration: const InputDecoration(labelText: 'اسم صاحب البطاقة', border: OutlineInputBorder()),
                    validator: (v) => v == null || v.trim().isEmpty ? 'الرجاء إدخال الاسم' : null,
                  ),
                  const SizedBox(height: 16),
                  
                  TextFormField(
                    controller: numberController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'رقم البطاقة', hintText: '1234 5678 1234 5678', border: OutlineInputBorder()),
                    validator: (v) => v == null || v.trim().length < 16 ? 'الرجاء إدخال رقم بطاقة صحيح' : null,
                  ),
                  const SizedBox(height: 16),
                  
                  Row(
                    children: [
                      Expanded(
                        child: TextFormField(
                          controller: expiryController,
                          decoration: const InputDecoration(labelText: 'تاريخ الانتهاء', hintText: 'MM/YY', border: OutlineInputBorder()),
                          validator: (v) => v == null || !v.contains('/') ? 'تاريخ غير صحيح' : null,
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: TextFormField(
                          controller: cvvController,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(labelText: 'رمز الأمان (CVV)', border: OutlineInputBorder()),
                          validator: (v) => v == null || v.length < 3 ? 'CVV غير صحيح' : null,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryColor),
                      onPressed: () {
                        final formState = formKey.currentState;
                        if (formState != null && formState.validate()) {
                          final cardNum = numberController.text;
                          final last4 = cardNum.length >= 4 
                              ? cardNum.substring(cardNum.length - 4) 
                              : cardNum;
                          final newCard = PaymentCard(
                            id: 'card_${DateTime.now().millisecondsSinceEpoch}',
                            holderName: holderController.text.toUpperCase(),
                            cardNumber: '**** **** **** $last4',
                            expiryDate: expiryController.text,
                            cvv: cvvController.text,
                            cardType: cardType,
                          );
                          
                          context.read<PaymentProvider>().addCard(newCard);
                          Navigator.pop(ctx);
                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم حفظ البطاقة بنجاح!')));
                        }
                      },
                      child: const Text('حفظ البطاقة', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                    ),
                  ),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
