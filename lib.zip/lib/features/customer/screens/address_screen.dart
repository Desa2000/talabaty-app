import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:flutter/services.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/providers/address_provider.dart';
import '../../../data/models/user_model.dart';

class AddressScreen extends StatelessWidget {
  const AddressScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final addressProvider = context.watch<AddressProvider>();
    final addresses = addressProvider.addresses;
    final selectedId = addressProvider.selectedAddressId;

    return Scaffold(
      appBar: AppBar(
        title: const Text('اختر موقعك'),
        actions: [
          IconButton(
            icon: const Icon(Icons.share), 
            onPressed: () {
              final selected = addressProvider.selectedAddress;
              if (selected != null) {
                Clipboard.setData(ClipboardData(text: '${selected.title}: ${selected.area}، ${selected.street}'));
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم نسخ العنوان إلى الحافظة لمشاركته!')));
              } else {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('الرجاء اختيار عنوان أولاً لمشاركته')));
              }
            }
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'ابحث عن منطقة أو عنوان...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: const Icon(Icons.tune),
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
          
          Expanded(
            child: Container(
              width: double.infinity,
              color: AppColors.borderGray.withValues(alpha: 0.3),
              child: FlutterMap(
                options: MapOptions(
                  initialCenter: addressProvider.selectedAddress != null 
                      ? LatLng(addressProvider.selectedAddress!.latitude, addressProvider.selectedAddress!.longitude)
                      : const LatLng(15.5007, 32.5599),
                  initialZoom: 15.0,
                ),
                children: [
                  TileLayer(
                    urlTemplate: 'https://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}',
                    userAgentPackageName: 'com.example.talabaty_app',
                  ),
                  if (addressProvider.selectedAddress != null)
                    MarkerLayer(
                      markers: [
                        Marker(
                          point: LatLng(addressProvider.selectedAddress!.latitude, addressProvider.selectedAddress!.longitude),
                          width: 40,
                          height: 40,
                          child: const Icon(Icons.location_on, color: AppColors.primaryColor, size: 40),
                        ),
                      ],
                    ),
                ],
              ),
            ),
          ),
          
          Container(
            color: Colors.white,
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('المواقع المحفوظة', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    Text('${addresses.length} / 3', style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
                  ],
                ),
                const SizedBox(height: 16),
                
                if (addresses.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 20),
                    child: Center(child: Text('لا توجد مواقع محفوظة', style: TextStyle(color: AppColors.textSecondary))),
                  )
                else
                  ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: addresses.length,
                    itemBuilder: (context, index) {
                      final addr = addresses[index];
                      return _buildAddressItem(context, addr, selectedId == addr.id);
                    },
                  ),
                  
                const SizedBox(height: 16),
                ElevatedButton.icon(
                  onPressed: () async {
                    if (addresses.length >= 3) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('لا يمكنك إضافة أكثر من 3 مواقع. الرجاء حذف موقع لإضافة جديد.')),
                      );
                      return;
                    }
                    
                    // Navigate to Map Picker
                    final result = await context.push('/customer/map_picker');
                    if (result != null && result is LatLng && context.mounted) {
                      _showNameAddressDialog(context, result);
                    }
                  },
                  icon: const Icon(Icons.add_location_alt),
                  label: const Text('إضافة عنوان جديد'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAddressItem(BuildContext context, AddressModel address, bool isSelected) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        border: Border.all(color: isSelected ? AppColors.primaryColor : AppColors.borderGray),
        borderRadius: BorderRadius.circular(12),
        color: isSelected ? AppColors.accentCream : Colors.white,
      ),
      child: Material(
        color: Colors.transparent,
        child: ListTile(
          leading: Icon(
            isSelected ? Icons.radio_button_checked : Icons.radio_button_off,
            color: isSelected ? AppColors.primaryColor : AppColors.textSecondary,
          ),
          title: Text(address.title, style: const TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text('${address.area}، ${address.street}', style: const TextStyle(color: AppColors.textSecondary)),
          trailing: IconButton(
            icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
            onPressed: () {
              context.read<AddressProvider>().removeAddress(address.id);
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم حذف الموقع بنجاح')));
            },
          ),
          onTap: () {
            context.read<AddressProvider>().selectAddress(address.id);
            context.pop(address.title);
          },
        ),
      ),
    );
  }

  void _showNameAddressDialog(BuildContext context, LatLng location) {
    final TextEditingController nameController = TextEditingController();
    
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حفظ الموقع الجديد'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('الرجاء إدخال اسم لهذا الموقع (مثال: المنزل, العمل):', style: TextStyle(fontSize: 14)),
            const SizedBox(height: 12),
            TextField(
              controller: nameController,
              decoration: const InputDecoration(
                hintText: 'اسم الموقع',
                border: OutlineInputBorder(),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('إلغاء', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryColor),
            onPressed: () {
              final title = nameController.text.trim();
              if (title.isEmpty) return;
              
              final newAddress = AddressModel(
                id: 'addr_${DateTime.now().millisecondsSinceEpoch}',
                title: title,
                city: 'الخرطوم', // mock
                area: 'موقع جديد',
                street: 'إحداثيات: ${location.latitude.toStringAsFixed(3)}, ${location.longitude.toStringAsFixed(3)}',
                landmark: '',
                latitude: location.latitude,
                longitude: location.longitude,
                phone: '',
              );
              
              final success = context.read<AddressProvider>().addAddress(newAddress);
              Navigator.pop(ctx);
              
              if (success) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم إضافة الموقع بنجاح')));
              } else {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('عذراً، وصلت للحد الأقصى للمواقع')));
              }
            },
            child: const Text('حفظ', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }
}
