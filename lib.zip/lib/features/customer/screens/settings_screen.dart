import 'package:flutter/material.dart';
import 'package:talabaty_app/core/utils/directional_extensions.dart';
import '../../../core/constants/app_colors.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _notificationsEnabled = true;
  bool _darkModeEnabled = false;
  String _currentLanguage = 'العربية';

  void _showLanguageDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('اختر لغة التطبيق'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            RadioListTile<String>(
              title: const Text('العربية'),
              value: 'العربية',
              groupValue: _currentLanguage,
              activeColor: AppColors.primaryColor,
              onChanged: (val) {
                setState(() => _currentLanguage = val!);
                Navigator.pop(ctx);
              },
            ),
            RadioListTile<String>(
              title: const Text('English'),
              value: 'English',
              groupValue: _currentLanguage,
              activeColor: AppColors.primaryColor,
              onChanged: (val) {
                setState(() => _currentLanguage = val!);
                Navigator.pop(ctx);
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showTextDialog(String title, String content) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: SingleChildScrollView(child: Text(content, style: const TextStyle(height: 1.5))),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('إغلاق'),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      appBar: AppBar(
        title: const Text('الإعدادات'),
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionHeader('عام'),
            _buildSettingsContainer([
              _buildSwitchItem(
                icon: Icons.dark_mode,
                iconColor: Colors.deepPurple,
                title: 'الوضع الليلي',
                value: _darkModeEnabled,
                onChanged: (val) => setState(() => _darkModeEnabled = val),
              ),
              const Divider(height: 1, indent: 60),
              _buildNavigationItem(
                icon: Icons.language,
                iconColor: Colors.blue,
                title: 'اللغة',
                trailingText: _currentLanguage,
                onTap: _showLanguageDialog,
              ),
            ]),
            
            const SizedBox(height: 24),
            _buildSectionHeader('الإشعارات'),
            _buildSettingsContainer([
              _buildSwitchItem(
                icon: Icons.notifications_active,
                iconColor: Colors.orange,
                title: 'السماح بالإشعارات',
                value: _notificationsEnabled,
                onChanged: (val) => setState(() => _notificationsEnabled = val),
              ),
            ]),
            
            const SizedBox(height: 24),
            _buildSectionHeader('معلومات'),
            _buildSettingsContainer([
              _buildNavigationItem(
                icon: Icons.privacy_tip,
                iconColor: Colors.green,
                title: 'سياسة الخصوصية',
                onTap: () => _showTextDialog(
                  'سياسة الخصوصية',
                  'نحن في تطبيق طلباتي نلتزم بحماية خصوصيتك وبياناتك الشخصية. يتم جمع بعض البيانات فقط لتحسين جودة التوصيل واقتراح المطاعم الأقرب إليك، ولا يتم بيع أو مشاركة هذه البيانات مع أي أطراف ثالثة.',
                ),
              ),
              const Divider(height: 1, indent: 60),
              _buildNavigationItem(
                icon: Icons.description,
                iconColor: Colors.grey.shade700,
                title: 'الشروط والأحكام',
                onTap: () => _showTextDialog(
                  'الشروط والأحكام',
                  'باستخدامك لتطبيق طلباتي، فإنك توافق على الشروط والأحكام الخاصة بالخدمة. يجب تقديم معلومات صحيحة عند التسجيل واختيار العناوين بدقة لضمان وصول الطلب في الوقت المناسب.',
                ),
              ),
              const Divider(height: 1, indent: 60),
              _buildNavigationItem(
                icon: Icons.info,
                iconColor: Colors.blueGrey,
                title: 'عن التطبيق',
                trailingText: 'v1.0.0',
                onTap: () => _showTextDialog(
                  'عن تطبيق طلباتي',
                  'طلباتي هو تطبيق رائد لتوصيل الطعام والمستلزمات يهدف لتسهيل عملية الطلب وربط العملاء بأفضل المطاعم المحلية مع توفير شبكة توصيل سريعة ومندوبين جاهزين لخدمتك في أي وقت.',
                ),
              ),
            ]),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12, left: 8, right: 8),
      child: Text(
        title,
        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.grey),
      ),
    );
  }

  Widget _buildSettingsContainer(List<Widget> children) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(color: Colors.black.withValues(alpha: 0.03), blurRadius: 10, offset: const Offset(0, 4))
        ],
      ),
      child: Column(
        children: children,
      ),
    );
  }

  Widget _buildSwitchItem({required IconData icon, required Color iconColor, required String title, required bool value, required ValueChanged<bool> onChanged}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(color: iconColor.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(10)),
            child: Icon(icon, color: iconColor, size: 20),
          ),
          const SizedBox(width: 16),
          Expanded(child: Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500))),
          Switch(
            value: value,
            onChanged: onChanged,
            activeColor: AppColors.primaryColor,
          ),
        ],
      ),
    );
  }

  Widget _buildNavigationItem({required IconData icon, required Color iconColor, required String title, String? trailingText, required VoidCallback onTap}) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: iconColor.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(10)),
              child: Icon(icon, color: iconColor, size: 20),
            ),
            const SizedBox(width: 16),
            Expanded(child: Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500))),
            if (trailingText != null)
              Text(trailingText, style: const TextStyle(color: Colors.grey, fontSize: 14)),
            const SizedBox(width: 8),
            Icon(context.forwardIconIos, size: 16, color: Colors.grey.shade400),
          ],
        ),
      ),
    );
  }
}
