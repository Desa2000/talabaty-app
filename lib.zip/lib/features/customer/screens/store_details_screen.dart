import 'package:talabaty_app/core/widgets/custom_image.dart';
import 'package:talabaty_app/core/utils/directional_extensions.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:talabaty_app/core/providers/data_provider.dart';
import 'package:talabaty_app/core/providers/cart_provider.dart';
import 'package:talabaty_app/core/constants/app_colors.dart';
import 'package:talabaty_app/core/constants/enums.dart';
import 'package:talabaty_app/data/models/store_model.dart';

class StoreDetailsScreen extends StatefulWidget {
  final String storeId;
  const StoreDetailsScreen({super.key, required this.storeId});

  @override
  State<StoreDetailsScreen> createState() => _StoreDetailsScreenState();
}

class _StoreDetailsScreenState extends State<StoreDetailsScreen> with SingleTickerProviderStateMixin {
  TabController? _tabController;
  String _selectedCategory = '';

  @override
  void dispose() {
    _tabController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final dataProvider = context.watch<DataProvider>();
    final store = dataProvider.stores.firstWhere(
      (s) => s.id == widget.storeId,
      orElse: () => dataProvider.stores.isNotEmpty
          ? dataProvider.stores.first
          : StoreModel(
              id: widget.storeId,
              ownerId: '',
              name: 'المحل غير متوفر',
              type: StoreType.restaurant,
              logo: '',
              coverImage: '',
              phone: '',
              area: '',
              street: '',
              landmark: '',
              latitude: 0,
              longitude: 0,
              openingTime: '',
              closingTime: '',
              preparationTime: '',
              minimumOrder: 0,
              deliveryFee: 0,
            ),
    );
    final products = dataProvider.products.where((p) => p.storeId == widget.storeId).toList();
    final cart = context.watch<CartProvider>();

    final List<String> categories = products.map((p) => p.category).toSet().toList();
    
    if (categories.isNotEmpty) {
      if (_tabController == null || _tabController!.length != categories.length) {
        _tabController?.dispose();
        _tabController = TabController(length: categories.length, vsync: this);
        _selectedCategory = categories.first;
        _tabController!.addListener(() {
          if (!_tabController!.indexIsChanging) {
            setState(() {
              _selectedCategory = categories[_tabController!.index];
            });
          }
        });
      }
    } else {
      _tabController?.dispose();
      _tabController = null;
      _selectedCategory = '';
    }

    final filteredProducts = products.where((p) => p.category == _selectedCategory).toList();

    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          // 1. Sleek Cover Image with Premium Back/Action buttons
          SliverAppBar(
            expandedHeight: 240,
            pinned: true,
            elevation: 0,
            backgroundColor: AppColors.primaryColor,
            leading: Padding(
              padding: const EdgeInsets.all(8.0),
              child: CircleAvatar(
                backgroundColor: Colors.black.withValues(alpha: 0.4),
                child: IconButton(
                  icon: Icon(context.backIcon, color: Colors.white, size: 20),
                  onPressed: () => context.pop(),
                ),
              ),
            ),
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                fit: StackFit.expand,
                children: [
                  Hero(
                    tag: 'store_image_${store.id}',
                    child: CustomImage(
                      imagePath: store.logo ?? 'https://via.placeholder.com/150', 
                      fit: BoxFit.cover,
                    ),
                  ),
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.black.withValues(alpha: 0.6),
                          Colors.transparent,
                          Colors.black.withValues(alpha: 0.5),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            actions: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: CircleAvatar(
                  backgroundColor: Colors.black.withValues(alpha: 0.4),
                  child: IconButton(
                    icon: const Icon(Icons.favorite_border_rounded, color: Colors.white, size: 20),
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('تمت الإضافة للمفضلة'), behavior: SnackBarBehavior.floating),
                      );
                    },
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 12, right: 4),
                child: CircleAvatar(
                  backgroundColor: Colors.black.withValues(alpha: 0.4),
                  child: IconButton(
                    icon: const Icon(Icons.share_rounded, color: Colors.white, size: 20),
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('قريباً: مشاركة المطعم'), behavior: SnackBarBehavior.floating),
                      );
                    },
                  ),
                ),
              ),
            ],
          ),

          // 2. Premium Restaurant Info Card
          SliverToBoxAdapter(
            child: Container(
              transform: Matrix4.translationValues(0, -32, 0),
              margin: const EdgeInsets.symmetric(horizontal: 16),
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: AppColors.borderGray.withValues(alpha: 0.6), width: 1.5),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.05),
                    blurRadius: 20,
                    offset: const Offset(0, 10),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Text(
                    store.name,
                    style: const TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.w900,
                      color: AppColors.textPrimary,
                      fontFamily: 'Cairo',
                      letterSpacing: -0.3,
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Divider(height: 1, color: AppColors.borderGray),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _buildInfoColumn(Icons.star_rounded, '${store.rating}', 'تقييم', Colors.amber),
                      _buildInfoColumn(Icons.access_time_rounded, store.preparationTime, 'وقت التحضير', AppColors.primaryColor),
                      _buildInfoColumn(Icons.delivery_dining_rounded, '${store.deliveryFee.toInt()} ج.س', 'التوصيل', Colors.blue),
                    ],
                  ),
                ],
              ),
            ),
          ),

          // 3. Sticky Categories — Vibrant Pill Chip TabBar
          if (categories.isNotEmpty)
            SliverPersistentHeader(
              pinned: true,
              delegate: _SliverAppBarDelegate(
                TabBar(
                  controller: _tabController,
                  isScrollable: true,
                  indicatorColor: Colors.transparent,
                  dividerColor: Colors.transparent,
                  indicator: const BoxDecoration(),
                  labelPadding: const EdgeInsets.symmetric(horizontal: 6),
                  physics: const BouncingScrollPhysics(),
                  tabs: categories.asMap().entries.map((entry) {
                    final isSelected = _selectedCategory == entry.value;
                    return _PillTab(
                      label: entry.value,
                      isSelected: isSelected,
                    );
                  }).toList(),
                ),
              ),
            ),

          // 4. Products List
          if (filteredProducts.isEmpty)
            const SliverFillRemaining(
              child: Center(
                child: Text(
                  'لا توجد منتجات في هذا القسم',
                  style: TextStyle(color: AppColors.textSecondary, fontSize: 16, fontFamily: 'Cairo'),
                ),
              ),
            )
          else
            SliverPadding(
              padding: const EdgeInsets.all(16).copyWith(bottom: 120), // padding for floating cart
              sliver: SliverList(
                delegate: SliverChildBuilderDelegate(
                  (context, index) {
                    final p = filteredProducts[index];
                    return InkWell(
                      onTap: () => context.push('/customer/product/${p.id}'),
                      borderRadius: BorderRadius.circular(20),
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 16),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: AppColors.borderGray.withValues(alpha: 0.5), width: 1),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.02),
                              blurRadius: 10,
                              offset: const Offset(0, 4),
                            )
                          ],
                        ),
                        child: Row(
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(16),
                              child: CustomImage(
                                imagePath: p.image, 
                                fit: BoxFit.cover,
                                width: 95,
                                height: 95,
                              ),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    p.name,
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                      color: AppColors.textPrimary,
                                      fontFamily: 'Cairo',
                                    ),
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    p.description,
                                    style: const TextStyle(
                                      color: AppColors.textSecondary,
                                      fontSize: 12,
                                      fontFamily: 'Cairo',
                                    ),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  const SizedBox(height: 12),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        children: [
                                          Text(
                                            '${p.discountPrice ?? p.price} ج.س',
                                            style: const TextStyle(
                                              color: AppColors.primaryColor,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 15,
                                              fontFamily: 'Cairo',
                                            ),
                                          ),
                                          if (p.discountPrice != null) ...[
                                            const SizedBox(width: 8),
                                            Text(
                                              '${p.price}',
                                              style: const TextStyle(
                                                color: Colors.grey,
                                                fontSize: 11,
                                                decoration: TextDecoration.lineThrough,
                                                fontFamily: 'Cairo',
                                              ),
                                            ),
                                          ]
                                        ],
                                      ),
                                      Container(
                                        padding: const EdgeInsets.all(8),
                                        decoration: BoxDecoration(
                                          color: AppColors.primaryColor.withValues(alpha: 0.1),
                                          shape: BoxShape.circle,
                                        ),
                                        child: const Icon(Icons.add_rounded, color: AppColors.primaryColor, size: 18),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ).animate().fade(duration: 400.ms, delay: Duration(milliseconds: 50 * index)).slideX(begin: 0.06, end: 0);
                  },
                  childCount: filteredProducts.length,
                ),
              ),
            ),
        ],
      ),
      // 5. Stunning Premium Floating Cart Bottom Bar
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: cart.items.isNotEmpty
          ? Container(
              margin: const EdgeInsets.symmetric(horizontal: 20),
              height: 62,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.primaryColor.withValues(alpha: 0.35),
                    blurRadius: 20,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primaryColor,
                    elevation: 0,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                  ),
                  onPressed: () => context.push('/customer/checkout'),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          '${cart.items.length}',
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Cairo',
                          ),
                        ),
                      ),
                      const Text(
                        'عرض السلة',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Cairo',
                        ),
                      ),
                      Text(
                        '${cart.totalPrice} ج.س',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Cairo',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ).animate().slideY(begin: 1.0, end: 0, duration: 400.ms, curve: Curves.easeOutBack)
          : null,
    );
  }

  Widget _buildInfoColumn(IconData icon, String title, String subtitle, Color iconColor) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: iconColor.withValues(alpha: 0.08),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, color: iconColor, size: 24),
        ),
        const SizedBox(height: 8),
        Text(
          title,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 15,
            color: AppColors.textPrimary,
            fontFamily: 'Cairo',
          ),
        ),
        const SizedBox(height: 2),
        Text(
          subtitle,
          style: const TextStyle(
            color: AppColors.textSecondary,
            fontSize: 12,
            fontFamily: 'Cairo',
          ),
        ),
      ],
    );
  }
}

class _SliverAppBarDelegate extends SliverPersistentHeaderDelegate {
  _SliverAppBarDelegate(this._tabBar);

  final TabBar _tabBar;

  @override
  double get minExtent => _tabBar.preferredSize.height + 20.0;

  @override
  double get maxExtent => _tabBar.preferredSize.height + 20.0;

  @override
  Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: _tabBar,
    );
  }

  @override
  bool shouldRebuild(_SliverAppBarDelegate oldDelegate) {
    return false;
  }
}

/// Vibrant pill-shaped tab chip with orange gradient when selected
class _PillTab extends StatelessWidget {
  final String label;
  final bool isSelected;

  const _PillTab({required this.label, required this.isSelected});

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeInOut,
      margin: const EdgeInsets.symmetric(vertical: 2),
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 9),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(50),
        gradient: isSelected
            ? const LinearGradient(
                colors: [AppColors.primaryColor, Color(0xFFFFAB00)],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              )
            : null,
        color: isSelected ? null : const Color(0xFFF0F0F0),
        boxShadow: isSelected
            ? [
                BoxShadow(
                  color: AppColors.primaryColor.withValues(alpha: 0.35),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ]
            : null,
      ),
      child: Text(
        label,
        style: TextStyle(
          fontFamily: 'Cairo',
          fontWeight: isSelected ? FontWeight.w800 : FontWeight.w500,
          fontSize: 14,
          color: isSelected ? Colors.white : AppColors.textSecondary,
        ),
      ),
    );
  }
}

