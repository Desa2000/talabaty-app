import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'customer_home_screen.dart';
import 'search_screen.dart';
import 'my_orders_screen.dart';
import 'profile_screen.dart';
import 'cart_screen.dart';
import '../../../core/providers/cart_provider.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/utils/location_helper.dart';

class CustomerMainScreen extends StatefulWidget {
  const CustomerMainScreen({super.key});

  @override
  State<CustomerMainScreen> createState() => _CustomerMainScreenState();
}

class _CustomerMainScreenState extends State<CustomerMainScreen> {
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    LocationHelper.requestLocationPermission();
  }

  final List<Widget> _pages = [
    const CustomerHomeScreen(),
    const SearchScreen(),
    const MyOrdersScreen(),
    const ProfileScreen(),
  ];

  Widget _buildNavItem(int index, IconData activeIcon, IconData inactiveIcon, String label) {
    final isSelected = _currentIndex == index;
    final primaryColor = HSLColor.fromAHSL(1.0, 25.0, 1.0, 0.50).toColor(); // Orange HSL
    
    return Expanded(
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => setState(() => _currentIndex = index),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          alignment: Alignment.center,
          child: AnimatedContainer(
            duration: 250.ms,
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            decoration: BoxDecoration(
              color: isSelected ? primaryColor.withValues(alpha: 0.1) : Colors.transparent,
              borderRadius: BorderRadius.circular(20),
            ),
            child: FittedBox(
              fit: BoxFit.scaleDown,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    isSelected ? activeIcon : inactiveIcon,
                    color: isSelected ? primaryColor : Colors.grey.shade500,
                    size: 20,
                  ).animate(target: isSelected ? 1.0 : 0.0)
                   .scale(begin: const Offset(1, 1), end: const Offset(1.15, 1.15), duration: 200.ms, curve: Curves.easeOutBack),
                  if (isSelected) ...[
                    const SizedBox(width: 4),
                    MediaQuery(
                      data: MediaQuery.of(context).copyWith(textScaler: TextScaler.noScaling),
                      child: Text(
                        label,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: primaryColor,
                          fontWeight: FontWeight.bold,
                          fontSize: 11,
                          fontFamily: 'Cairo',
                        ),
                      ),
                    ).animate().fade(duration: 150.ms).slideX(begin: 0.1, end: 0, duration: 150.ms),
                  ]
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cartProvider = context.watch<CartProvider>();
    final cartCount = cartProvider.items.length;

    return Scaffold(
      extendBody: true, // Allows the Scaffold body to flow under the floating bottom bar
      body: IndexedStack(
        index: _currentIndex,
        children: _pages,
      ),
      floatingActionButton: cartCount > 0 && _currentIndex == 0
          ? Padding(
              padding: const EdgeInsets.only(bottom: 76.0), // Raise FAB above the floating bar
              child: FloatingActionButton.extended(
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const CartScreen()),
                ),
                backgroundColor: AppColors.primaryColor,
                icon: const Icon(Icons.shopping_cart, color: Colors.white),
                label: Text(
                  '$cartCount عنصر في السلة',
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
              ),
            )
          : null,
      bottomNavigationBar: SafeArea(
        child: Container(
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.95),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: AppColors.borderGray.withValues(alpha: 0.8), width: 1),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.05),
                blurRadius: 20,
                offset: const Offset(0, 8),
              )
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildNavItem(0, Icons.home_rounded, Icons.home_outlined, 'الرئيسية'),
              _buildNavItem(1, Icons.search_rounded, Icons.search_outlined, 'البحث'),
              _buildNavItem(2, Icons.receipt_long_rounded, Icons.receipt_long_outlined, 'الطلبات'),
              _buildNavItem(3, Icons.person_rounded, Icons.person_outline_rounded, 'حسابي'),
            ],
          ),
        ),
      ),
    );
  }
}
