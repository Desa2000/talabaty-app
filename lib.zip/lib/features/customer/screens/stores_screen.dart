import 'package:talabaty_app/core/widgets/custom_image.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/providers/data_provider.dart';
import '../../../core/constants/enums.dart';

class StoresScreen extends StatelessWidget {
  final String categoryType;
  const StoresScreen({super.key, required this.categoryType});

  @override
  Widget build(BuildContext context) {
    final dataProvider = context.watch<DataProvider>();
    
    StoreType? targetType;
    String title = '';
    
    if (categoryType == 'restaurant') {
      targetType = StoreType.restaurant;
      title = 'المطاعم';
    } else if (categoryType == 'supermarket') {
      targetType = StoreType.supermarket;
      title = 'السوبرماركت';
    } else if (categoryType == 'pharmacy') {
      targetType = StoreType.pharmacy;
      title = 'الصيدليات';
    } else if (categoryType == 'gift') {
      targetType = StoreType.gift;
      title = 'الهدايا';
    }

    final stores = dataProvider.stores.where((s) => s.type == targetType).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text(title),
      ),
      body: Directionality(
        textDirection: TextDirection.rtl,
        child: stores.isEmpty 
          ? const Center(child: Text('لا توجد متاجر حالياً'))
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: stores.length,
              itemBuilder: (context, index) {
                final store = stores[index];
                return GestureDetector(
                  onTap: () => context.push('/customer/store/${store.id}'),
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 10)],
                      border: Border.all(color: AppColors.borderGray, width: 1),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        ClipRRect(
                          borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
                          child: CustomImage(imagePath: 
                            store.logo ?? 'https://via.placeholder.com/150', fit: BoxFit.cover),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(store.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                              const SizedBox(height: 8),
                              Row(
                                children: [
                                  const Icon(Icons.star, color: Colors.amber, size: 18),
                                  const SizedBox(width: 4),
                                  Text('${store.rating}', style: const TextStyle(fontWeight: FontWeight.bold)),
                                  const SizedBox(width: 16),
                                  const Icon(Icons.location_on, color: Colors.grey, size: 18),
                                  const SizedBox(width: 4),
                                  Expanded(child: Text('${store.area} - ${store.street}', style: const TextStyle(color: Colors.grey, fontSize: 14))),
                                ],
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                );
              },
            ),
      ),
    );
  }
}

