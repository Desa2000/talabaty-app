import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import '../../../core/constants/enums.dart';
import '../../../core/providers/data_provider.dart';
import '../../../core/constants/app_colors.dart';
import '../../../data/models/order_model.dart';
import '../../../data/models/store_model.dart';
import '../../../data/models/user_model.dart';

class CourierDeliveryScreen extends StatefulWidget {
  final String orderId;
  const CourierDeliveryScreen({super.key, required this.orderId});

  @override
  State<CourierDeliveryScreen> createState() => _CourierDeliveryScreenState();
}

class _CourierDeliveryScreenState extends State<CourierDeliveryScreen> with SingleTickerProviderStateMixin {
  final MapController _mapController = MapController();
  late AnimationController _animationController;
  late Animation<double> _animation;
  LatLng? _courierCurrentPosition;
  double _distanceInMeters = 0.0;
  DateTime? _lastCameraUpdate;
  bool _isAnimating = false;

  @override
  void initState() {
    super.initState();

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 30),
    );
    _animation = Tween<double>(begin: 0.0, end: 1.0).animate(_animationController)
      ..addListener(() {
        _updateCourierPosition();
      });
  }

  @override
  void dispose() {
    _animationController.dispose();
    _mapController.dispose();
    super.dispose();
  }

  void _updateCourierPosition() {
    final dataProvider = context.read<DataProvider>();
    final order = dataProvider.orders.firstWhere(
      (o) => o.id == widget.orderId,
      orElse: () => dataProvider.orders.isNotEmpty
          ? dataProvider.orders.first
          : OrderModel(id: 'dummy', customerId: 'c1', storeId: 's1', items: [], address: AddressModel(id: 'dummy', title: 'Default', city: 'Khartoum', area: 'Bahri', street: 'Main St', landmark: '', latitude: 15.5, longitude: 32.5, phone: ''), customerLat: 15.5, customerLng: 32.5, storeLat: 15.5, storeLng: 32.5, subtotal: 0, deliveryFee: 0, serviceFee: 0, discount: 0, total: 0, paymentMethod: PaymentMethod.cashOnDelivery, paymentStatus: PaymentStatus.unpaid, status: OrderStatus.pending, createdAt: DateTime.now()),
    );
    
    // Simulate movement
    final lat = order.storeLat + (order.customerLat - order.storeLat) * _animation.value;
    final lng = order.storeLng + (order.customerLng - order.storeLng) * _animation.value;
    
    setState(() {
      _courierCurrentPosition = LatLng(lat, lng);
      _distanceInMeters = Geolocator.distanceBetween(
        lat, lng, order.customerLat, order.customerLng
      );
    });

    if (_courierCurrentPosition != null) {
      // Emit the new location to the backend
      dataProvider.courierUpdateLocation(widget.orderId, lat, lng);

      final now = DateTime.now();
      if (_lastCameraUpdate == null || now.difference(_lastCameraUpdate!).inSeconds >= 2) {
        _lastCameraUpdate = now;
        
        final customerLatLng = LatLng(order.customerLat, order.customerLng);
        final bounds = LatLngBounds.fromPoints([_courierCurrentPosition!, customerLatLng]);
        
        try {
          _mapController.fitCamera(
            CameraFit.bounds(
              bounds: bounds,
              padding: const EdgeInsets.all(50),
            )
          );
        } catch (e) {
          // Controller might not be ready
        }
      }
    }
  }

  void _checkStatusAndAnimate(OrderStatus status, double storeLat, double storeLng, double customerLat, double customerLng) {
    if (status == OrderStatus.onTheWay && !_isAnimating) {
      _isAnimating = true;
      _courierCurrentPosition ??= LatLng(storeLat, storeLng);
      _animationController.forward();
    } else if (status == OrderStatus.delivered && _isAnimating) {
      _animationController.stop();
      _isAnimating = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    final dataProvider = context.watch<DataProvider>();
    final order = dataProvider.orders.firstWhere(
      (o) => o.id == widget.orderId,
      orElse: () => dataProvider.orders.isNotEmpty
          ? dataProvider.orders.first
          : OrderModel(id: 'dummy', customerId: 'c1', storeId: 's1', items: [], address: AddressModel(id: 'dummy', title: 'Default', city: 'Khartoum', area: 'Bahri', street: 'Main St', landmark: '', latitude: 15.5, longitude: 32.5, phone: ''), customerLat: 15.5, customerLng: 32.5, storeLat: 15.5, storeLng: 32.5, subtotal: 0, deliveryFee: 0, serviceFee: 0, discount: 0, total: 0, paymentMethod: PaymentMethod.cashOnDelivery, paymentStatus: PaymentStatus.unpaid, status: OrderStatus.pending, createdAt: DateTime.now()),
    );
    final store = dataProvider.stores.firstWhere(
      (s) => s.id == order.storeId,
      orElse: () => dataProvider.stores.isNotEmpty
          ? dataProvider.stores.first
          : StoreModel(id: 'dummy', ownerId: '', name: 'متجر غير معروف', type: StoreType.restaurant, phone: '', area: '', street: '', landmark: '', latitude: 0, longitude: 0, openingTime: '', closingTime: '', preparationTime: '', minimumOrder: 0, deliveryFee: 0, status: '', rating: 0, ratingCount: 0),
    );

    final LatLng storeLatLng = LatLng(order.storeLat, order.storeLng);
    final LatLng customerLatLng = LatLng(order.customerLat, order.customerLng);
    
    // Set initial position if not animating
    if (_courierCurrentPosition == null && !_isAnimating) {
      _courierCurrentPosition = storeLatLng;
    }

    _checkStatusAndAnimate(order.status, order.storeLat, order.storeLng, order.customerLat, order.customerLng);

    List<Marker> markers = [
      Marker(
        point: storeLatLng,
        width: 40,
        height: 40,
        child: const Icon(Icons.location_on, color: Colors.orange, size: 40),
      ),
      Marker(
        point: customerLatLng,
        width: 40,
        height: 40,
        child: const Icon(Icons.location_on, color: Colors.blue, size: 40),
      ),
    ];

    if (_courierCurrentPosition != null) {
      markers.add(
        Marker(
          point: _courierCurrentPosition!,
          width: 60,
          height: 60,
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
              border: Border.all(color: Colors.orange, width: 2),
            ),
            child: const Center(
              child: Icon(Icons.delivery_dining, color: Colors.orange, size: 30),
            ),
          ),
        )
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('توصيل الطلب')),
      body: Column(
        children: [
          // Map Section
          Expanded(
            flex: 1,
            child: Stack(
              children: [
                FlutterMap(
                  mapController: _mapController,
                  options: MapOptions(
                    initialCenter: storeLatLng,
                    initialZoom: 14.0,
                  ),
                  children: [
                    TileLayer(
                      urlTemplate: 'https://mt1.google.com/vt/lyrs=m&x={x}&y={y}&z={z}',
                      userAgentPackageName: 'com.example.talabaty_app',
                    ),
                    PolylineLayer(
                      polylines: [
                        Polyline<Object>(
                          points: [storeLatLng, customerLatLng],
                          color: AppColors.primaryColor,
                          strokeWidth: 4,
                        ),
                      ],
                    ),
                    MarkerLayer(
                      markers: markers,
                    ),
                  ],
                ),
                if ((order.status == OrderStatus.onTheWay || order.status == OrderStatus.pickedUp) && _distanceInMeters > 0)
                  Positioned(
                    top: 16,
                    left: 16,
                    right: 16,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      decoration: BoxDecoration(
                        color: Colors.white.withAlpha(230),
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 10, offset: Offset(0, 4))],
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('المسافة للعميل', style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                              Text('${(_distanceInMeters / 1000).toStringAsFixed(2)} كم', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              const Text('الوقت المتوقع', style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                              Text('${(_distanceInMeters / 1000 * 3).ceil()} دقيقة', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: AppColors.primaryColor)),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
          
          // Details & Actions Section
          Expanded(
            flex: 1,
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: [
                          ListTile(
                            leading: const CircleAvatar(backgroundColor: AppColors.accentCream, child: Icon(Icons.store, color: AppColors.primaryColor)),
                            title: const Text('استلام من', style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                            subtitle: Text(store.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                          ),
                          const Divider(),
                          ListTile(
                            leading: const CircleAvatar(backgroundColor: AppColors.accentCream, child: Icon(Icons.person, color: AppColors.primaryColor)),
                            title: const Text('تسليم إلى', style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                            subtitle: Text('${order.address.area} - ${order.address.street}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                  _buildActionButtons(context, dataProvider, order),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons(BuildContext context, DataProvider provider, order) {
    return Column(
      children: [
        SizedBox(
          width: double.infinity,
          height: 60,
          child: ElevatedButton(
            onPressed: order.status == OrderStatus.assignedToCourier 
              ? () => provider.updateOrderStatus(order.id, OrderStatus.courierGoingToStore, 'المندوب يتجه للمطعم') 
              : null,
            style: ElevatedButton.styleFrom(backgroundColor: order.status == OrderStatus.assignedToCourier ? AppColors.primaryColor : Colors.grey),
            child: const Text('في الطريق للمطعم', style: TextStyle(fontSize: 18)),
          ),
        ),
        const SizedBox(height: 16),
        SizedBox(
          width: double.infinity,
          height: 60,
          child: ElevatedButton(
            onPressed: order.status == OrderStatus.courierGoingToStore 
              ? () => provider.updateOrderStatus(order.id, OrderStatus.pickedUp, 'تم استلام الطلب بنجاح') 
              : null,
            style: ElevatedButton.styleFrom(backgroundColor: order.status == OrderStatus.courierGoingToStore ? AppColors.primaryColor : Colors.grey),
            child: const Text('تم استلام الطلب', style: TextStyle(fontSize: 18)),
          ),
        ),
        const SizedBox(height: 16),
        SizedBox(
          width: double.infinity,
          height: 60,
          child: ElevatedButton(
            onPressed: order.status == OrderStatus.pickedUp 
              ? () {
                  provider.updateOrderStatus(order.id, OrderStatus.onTheWay, 'في الطريق للعميل');
                  _checkStatusAndAnimate(OrderStatus.onTheWay, order.storeLat, order.storeLng, order.customerLat, order.customerLng);
                }
              : null,
            style: ElevatedButton.styleFrom(backgroundColor: order.status == OrderStatus.pickedUp ? AppColors.primaryColor : Colors.grey),
            child: const Text('في الطريق للعميل', style: TextStyle(fontSize: 18)),
          ),
        ),
        const SizedBox(height: 16),
        SizedBox(
          width: double.infinity,
          height: 60,
          child: ElevatedButton(
            onPressed: order.status == OrderStatus.onTheWay 
              ? () {
                  provider.updateOrderStatus(order.id, OrderStatus.delivered, 'تم التوصيل بنجاح');
                  context.pop();
                } 
              : null,
            style: ElevatedButton.styleFrom(backgroundColor: order.status == OrderStatus.onTheWay ? Colors.green : Colors.grey),
            child: const Text('تم التوصيل!', style: TextStyle(fontSize: 18)),
          ),
        ),
      ],
    );
  }
}
