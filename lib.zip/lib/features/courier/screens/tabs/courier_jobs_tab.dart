import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../../core/constants/enums.dart';
import '../../../../core/providers/data_provider.dart';
import '../../../../core/providers/auth_provider.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../data/models/order_model.dart';
import '../../../../data/models/user_model.dart';
import '../../../../data/models/store_model.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';

class CourierJobsTab extends StatefulWidget {
  const CourierJobsTab({super.key});

  @override
  State<CourierJobsTab> createState() => _CourierJobsTabState();
}

class _CourierJobsTabState extends State<CourierJobsTab> {
  final Set<String> _rejectedOrders = {};
  final MapController _mapController = MapController();
  bool _isOnline = false; // Local online state
  
  LatLng _currentLocation = const LatLng(15.5007, 32.5599); // Khartoum default
  bool _isLoadingLocation = true;
  bool _isMapReady = false;

  @override
  void initState() {
    super.initState();
    _determinePosition();
  }

  Future<void> _determinePosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      _showLocationWarning('خدمات الموقع (GPS) مغلقة، يرجى تفعيلها من إعدادات الهاتف.');
      if (mounted) setState(() => _isLoadingLocation = false);
      return;
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        _showLocationWarning('التطبيق يحتاج لصلاحية الموقع لتحديد موقعك وتلقي الطلبات.');
        if (mounted) setState(() => _isLoadingLocation = false);
        return;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      _showLocationWarning('صلاحية الموقع مرفوضة دائماً. يرجى تفعيلها من إعدادات التطبيق.');
      if (mounted) setState(() => _isLoadingLocation = false);
      return;
    }

    final position = await Geolocator.getCurrentPosition();
    if (mounted) {
      setState(() {
        _currentLocation = LatLng(position.latitude, position.longitude);
        _isLoadingLocation = false;
      });
      if (_isMapReady) {
        _mapController.move(_currentLocation, 14.0);
      }
    }
  }

  void _showLocationWarning(String message) {
    if (!mounted) return;
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('تنبيه الموقع', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.red)),
        content: Text(message),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('حسناً'),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final dataProvider = context.watch<DataProvider>();
    
    final courierId = auth.currentUser?.id ?? '';
    // For MVP, if auth user is not courier, pick first courier
    final courier = dataProvider.couriers.firstWhere(
      (c) => c.userId == courierId,
      orElse: () => dataProvider.couriers.isNotEmpty
          ? dataProvider.couriers.first
          : CourierProfile(userId: courierId, nationalId: '123', dateOfBirth: '1995-01-01', emergencyPhone: '123', vehicleType: VehicleType.motorcycle),
    ); 
    final courierUser = dataProvider.users.firstWhere(
      (u) => u.id == courier.userId,
      orElse: () => dataProvider.users.isNotEmpty
          ? dataProvider.users.first
          : UserModel(id: 'dummy', name: 'سائق تجريبي', email: '', phone: '123', password: '', role: UserRole.courier, createdAt: DateTime.now()),
    );

    final myOrders = dataProvider.getOrdersForCourier(courier.userId);
    final activeOrder = myOrders.where((o) => o.status != OrderStatus.delivered && o.status != OrderStatus.cancelled).firstOrNull;
    final availableOrders = dataProvider.getAvailableOrdersForCourier().where((o) => !_rejectedOrders.contains(o.id)).toList();
    
    final isOnline = _isOnline;

    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        title: Text('كابتن ${courierUser.name}'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 1,
      ),
      body: activeOrder != null
          ? _buildActiveOrderView(activeOrder)
          : Column(
              children: [
                // Real Interactive Map
                Expanded(
                  flex: 2,
                  child: Stack(
                    children: [
                      FlutterMap(
                        mapController: _mapController,
                        options: MapOptions(
                          initialCenter: _currentLocation,
                          initialZoom: 14.0,
                          onMapReady: () {
                            _isMapReady = true;
                            if (!_isLoadingLocation) {
                              _mapController.move(_currentLocation, 14.0);
                            }
                          },
                        ),
                        children: [
                          TileLayer(
                            urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                            userAgentPackageName: 'com.talabaty.app',
                          ),
                          MarkerLayer(
                            markers: [
                              // Courier current location marker
                              Marker(
                                point: _currentLocation,
                                width: 50,
                                height: 50,
                                child: _isLoadingLocation 
                                    ? const CircularProgressIndicator()
                                    : const Icon(Icons.motorcycle, color: Colors.blue, size: 40),
                              ),
                              // Available orders markers
                              ...availableOrders.map((order) {
                                return Marker(
                                  point: LatLng(order.storeLat, order.storeLng),
                                  width: 40,
                                  height: 40,
                                  child: const Icon(Icons.location_on, color: Colors.red, size: 40),
                                );
                              }),
                            ],
                          ),
                        ],
                      ),
                      Center(
                        child: GestureDetector(
                          onTap: () {
                            setState(() {
                              _isOnline = !_isOnline;
                            });
                          },
                          child: Container(
                            width: 150,
                            height: 150,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: isOnline ? Colors.green.withValues(alpha: 0.8) : Colors.black.withValues(alpha: 0.8),
                              boxShadow: [
                                BoxShadow(
                                  color: isOnline ? Colors.green.withValues(alpha: 0.5) : Colors.black.withValues(alpha: 0.5),
                                  blurRadius: 30,
                                  spreadRadius: 10,
                                )
                              ],
                            ),
                            child: Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(isOnline ? Icons.wifi : Icons.power_settings_new, color: Colors.white, size: 40),
                                  const SizedBox(height: 8),
                                  Text(
                                    isOnline ? 'متصل' : 'اضغط للاتصال',
                                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
                                  ),
                                ],
                              ),
                            ),
                          )
                          // Adding pulse animation if online
                          .animate(onPlay: (c) => isOnline ? c.repeat() : c.stop())
                          .scaleXY(begin: 1.0, end: 1.1, duration: 1.seconds, curve: Curves.easeInOut)
                          .then(delay: 0.ms)
                          .scaleXY(begin: 1.1, end: 1.0, duration: 1.seconds, curve: Curves.easeInOut),
                        ),
                      ),
                    ],
                  ),
                ),
                
                // Bottom Section: Orders List or Offline Status
                Expanded(
                  flex: 3,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(20),
                    decoration: const BoxDecoration(
                      color: AppColors.backgroundLight,
                      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (!isOnline) ...[
                          const Expanded(
                            child: Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.bedtime_outlined, size: 80, color: AppColors.borderGray),
                                  SizedBox(height: 16),
                                  Text('أنت الآن في وضع عدم الاتصال', style: TextStyle(fontSize: 18, color: AppColors.textSecondary, fontWeight: FontWeight.bold)),
                                  SizedBox(height: 8),
                                  Text('قم بالاتصال بالشبكة لاستقبال طلبات التوصيل', style: TextStyle(color: AppColors.textSecondary)),
                                ],
                              ),
                            ),
                          )
                        ] else if (availableOrders.isEmpty) ...[
                          const Expanded(
                            child: Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.radar, size: 80, color: AppColors.primaryColor),
                                  SizedBox(height: 16),
                                  Text('جاري البحث عن طلبات قريبة منك...', style: TextStyle(fontSize: 18, color: AppColors.textPrimary, fontWeight: FontWeight.bold)),
                                ],
                              ),
                            ),
                          )
                        ] else ...[
                          Text('طلبات التوصيل المتاحة (${availableOrders.length})', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 16),
                          Expanded(
                            child: ListView.builder(
                              itemCount: availableOrders.length,
                              itemBuilder: (context, index) {
                                return _buildAvailableOrderCard(context, availableOrders[index], courier.userId, dataProvider)
                                    .animate().fade(duration: 400.ms).slideX(begin: 0.1);
                              },
                            ),
                          ),
                        ]
                      ],
                    ),
                  ),
                ),
              ],
            ),
    );
  }

  Widget _buildActiveOrderView(OrderModel order) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.delivery_dining, size: 100, color: AppColors.primaryColor),
            const SizedBox(height: 24),
            const Text('لديك طلب قيد التوصيل!', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text('رقم الطلب #${order.id.substring(0, 8).toUpperCase()}', style: const TextStyle(fontSize: 16, color: AppColors.textSecondary)),
            const SizedBox(height: 32),
            SizedBox(
              width: double.infinity,
              height: 56,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primaryColor,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                onPressed: () => context.push('/courier/delivery/${order.id}'),
                child: const Text('متابعة التوصيل', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAvailableOrderCard(BuildContext context, OrderModel order, String courierId, DataProvider dataProvider) {
    final store = dataProvider.stores.firstWhere(
      (s) => s.id == order.storeId,
      orElse: () => dataProvider.stores.isNotEmpty
          ? dataProvider.stores.first
          : StoreModel(id: 'dummy', ownerId: '', name: 'متجر غير معروف', type: StoreType.restaurant, phone: '', area: '', street: '', landmark: '', latitude: 0, longitude: 0, openingTime: '', closingTime: '', preparationTime: '', minimumOrder: 0, deliveryFee: 0, status: '', rating: 0, ratingCount: 0),
    );
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.primaryColor.withValues(alpha: 0.3), width: 2),
        boxShadow: [BoxShadow(color: AppColors.primaryColor.withValues(alpha: 0.1), blurRadius: 10, spreadRadius: 2)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(color: Colors.orange.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(8)),
                child: const Text('طلب جديد', style: TextStyle(color: Colors.orange, fontWeight: FontWeight.bold)),
              ),
              Text('${order.deliveryFee} ج.س', style: const TextStyle(color: Colors.green, fontWeight: FontWeight.bold, fontSize: 18)),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: Colors.grey.withValues(alpha: 0.1), shape: BoxShape.circle), child: const Icon(Icons.store, color: AppColors.primaryColor)),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('استلام من', style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                Text(store.name, style: const TextStyle(fontWeight: FontWeight.bold)),
              ])),
            ],
          ),
          const Padding(padding: EdgeInsets.only(right: 20), child: SizedBox(height: 20, child: VerticalDivider(color: Colors.grey, thickness: 1))),
          Row(
            children: [
              Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: Colors.grey.withValues(alpha: 0.1), shape: BoxShape.circle), child: const Icon(Icons.location_on, color: Colors.green)),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('توصيل إلى', style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                Text(order.address.street, style: const TextStyle(fontWeight: FontWeight.bold)),
              ])),
            ],
          ),
          const SizedBox(height: 24),
          Row(
            children: [
              Expanded(
                flex: 1,
                child: OutlinedButton(
                  onPressed: () {
                    setState(() {
                      _rejectedOrders.add(order.id);
                    });
                  },
                  style: OutlinedButton.styleFrom(foregroundColor: Colors.red, side: const BorderSide(color: Colors.red), padding: const EdgeInsets.symmetric(vertical: 14)),
                  child: const Text('رفض', style: TextStyle(fontWeight: FontWeight.bold)),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                flex: 2,
                child: ElevatedButton(
                  onPressed: () {
                    dataProvider.courierAcceptOrder(order.id, courierId);
                  },
                  style: ElevatedButton.styleFrom(backgroundColor: AppColors.primaryColor, padding: const EdgeInsets.symmetric(vertical: 14)),
                  child: const Text('قبول الطلب', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white, fontSize: 16)),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
