import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/enums.dart';
import '../../../../core/providers/auth_provider.dart';
import '../../../../core/providers/data_provider.dart';
import '../../../../data/models/user_model.dart';
import '../../../../data/models/store_model.dart';

class CourierEarningsTab extends StatelessWidget {
  const CourierEarningsTab({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final dataProvider = context.watch<DataProvider>();
    
    final courierId = auth.currentUser?.id ?? '';
    final courier = dataProvider.couriers.firstWhere(
      (c) => c.userId == courierId,
      orElse: () => dataProvider.couriers.isNotEmpty
          ? dataProvider.couriers.first
          : CourierProfile(userId: courierId, nationalId: '123', dateOfBirth: '1995-01-01', emergencyPhone: '123', vehicleType: VehicleType.motorcycle),
    );

    final completedOrders = dataProvider.getOrdersForCourier(courier.userId)
        .where((o) => o.status == OrderStatus.delivered)
        .toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    
    // Calculate earnings from real orders
    final todayOrders = completedOrders.where((o) {
      final now = DateTime.now();
      return o.createdAt.year == now.year && o.createdAt.month == now.month && o.createdAt.day == now.day;
    }).toList();

    return Scaffold(
      backgroundColor: AppColors.backgroundLight,
      appBar: AppBar(
        title: const Text('المحفظة والأرباح'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 1,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Master Balance Card
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [AppColors.primaryColor, Color(0xFFE65C00)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(color: AppColors.primaryColor.withValues(alpha: 0.3), blurRadius: 15, offset: const Offset(0, 8)),
                ],
              ),
              child: Column(
                children: [
                  const Text('أرباح اليوم', style: TextStyle(color: Colors.white70, fontSize: 16)),
                  const SizedBox(height: 8),
                  Text('${courier.todayEarnings} ج.س', style: const TextStyle(color: Colors.white, fontSize: 36, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.2), borderRadius: BorderRadius.circular(20)),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.check_circle, color: Colors.white, size: 16),
                        const SizedBox(width: 8),
                        Text('تم إنجاز ${courier.totalDeliveries} رحلة', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                      ],
                    ),
                  )
                ],
              ),
            ),
            
            const SizedBox(height: 32),
            const Text('تحليل الأرباح الأسبوعية', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            
            // Bar Chart
            Container(
              height: 150,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 10)],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  _buildBar('الأحد', 0.4),
                  _buildBar('الاثنين', 0.6),
                  _buildBar('الثلاثاء', 0.8),
                  _buildBar('الأربعاء', 0.3),
                  _buildBar('الخميس', 0.9),
                  _buildBar('الجمعة', 1.0, isToday: true),
                  _buildBar('السبت', 0.0),
                ],
              ),
            ),
            
            const SizedBox(height: 32),
            Text('سجل الرحلات (${todayOrders.isEmpty ? 'لا يوجد' : 'اليوم'})', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            
            if (completedOrders.isEmpty)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(32),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
                child: Column(
                  children: [
                    Icon(Icons.delivery_dining, size: 48, color: Colors.grey.shade300),
                    const SizedBox(height: 12),
                    const Text('لا توجد رحلات مكتملة بعد', style: TextStyle(color: Colors.grey)),
                  ],
                ),
              )
            else
              ...completedOrders.take(10).map((order) {
                final store = dataProvider.stores.firstWhere(
                  (s) => s.id == order.storeId,
                  orElse: () => dataProvider.stores.isNotEmpty
                      ? dataProvider.stores.first
                      : StoreModel(id: 'dummy', ownerId: '', name: 'متجر غير معروف', type: StoreType.restaurant, phone: '', area: '', street: '', landmark: '', latitude: 0, longitude: 0, openingTime: '', closingTime: '', preparationTime: '', minimumOrder: 0, deliveryFee: 0, status: '', rating: 0, ratingCount: 0),
                );
                final timeStr = '${order.createdAt.hour}:${order.createdAt.minute.toString().padLeft(2, '0')}';
                return _buildTripItem(
                  'توصيلة من ${store.name}',
                  '${order.deliveryFee.toInt()} ج.س',
                  timeStr,
                );
              }),
            
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  Widget _buildBar(String day, double percent, {bool isToday = false}) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Container(
          width: 12,
          height: 100 * percent,
          decoration: BoxDecoration(
            color: isToday ? AppColors.primaryColor : Colors.grey.withValues(alpha: 0.3),
            borderRadius: BorderRadius.circular(6),
          ),
        ),
        const SizedBox(height: 8),
        Text(day, style: TextStyle(fontSize: 10, color: isToday ? AppColors.primaryColor : AppColors.textSecondary, fontWeight: isToday ? FontWeight.bold : FontWeight.normal)),
      ],
    );
  }

  Widget _buildTripItem(String title, String amount, String time) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.03), blurRadius: 5)],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: Colors.green.withValues(alpha: 0.1), shape: BoxShape.circle), child: const Icon(Icons.delivery_dining, color: Colors.green)),
              const SizedBox(width: 16),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  Text(time, style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                ],
              ),
            ],
          ),
          Text(amount, style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.green, fontSize: 16)),
        ],
      ),
    );
  }
}
