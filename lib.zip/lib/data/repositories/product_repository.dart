import '../models/product_model.dart';
import '../mock/mock_data.dart';

class ProductRepository {
  // Using MockData as our initial database
  final List<ProductModel> _mockDatabase = MockData.mockProducts;

  Future<List<ProductModel>> getProductsByStoreId(String storeId) async {
    await Future.delayed(const Duration(milliseconds: 500)); // Simulate network
    return _mockDatabase.where((p) => p.storeId == storeId).toList();
  }

  Future<ProductModel> addProduct(ProductModel product) async {
    await Future.delayed(const Duration(milliseconds: 500));
    _mockDatabase.add(product);
    return product;
  }

  Future<ProductModel> updateProduct(ProductModel product) async {
    await Future.delayed(const Duration(milliseconds: 500));
    final index = _mockDatabase.indexWhere((p) => p.id == product.id);
    if (index != -1) {
      _mockDatabase[index] = product;
      return product;
    }
    throw Exception('Product not found');
  }

  Future<void> deleteProduct(String productId) async {
    await Future.delayed(const Duration(milliseconds: 500));
    _mockDatabase.removeWhere((p) => p.id == productId);
  }

  Future<void> toggleProductAvailability(String productId, bool isAvailable) async {
    await Future.delayed(const Duration(milliseconds: 200));
    final index = _mockDatabase.indexWhere((p) => p.id == productId);
    if (index != -1) {
      _mockDatabase[index] = _mockDatabase[index].copyWith(isAvailable: isAvailable);
    }
  }

  Future<void> updateStock(String productId, int newQuantity) async {
    await Future.delayed(const Duration(milliseconds: 200));
    final index = _mockDatabase.indexWhere((p) => p.id == productId);
    if (index != -1) {
      _mockDatabase[index] = _mockDatabase[index].copyWith(stockQuantity: newQuantity);
    }
  }
}
